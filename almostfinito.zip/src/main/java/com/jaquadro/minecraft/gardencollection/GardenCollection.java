package com.jaquadro.minecraft.gardencollection;

import com.jaquadro.minecraft.gardencollection.api.CompostAPI;
import com.jaquadro.minecraft.gardencollection.registry.ModBlockEntities;
import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import com.jaquadro.minecraft.gardencollection.registry.ModCreativeTabs;
import com.jaquadro.minecraft.gardencollection.registry.ModItems;
import com.jaquadro.minecraft.gardencollection.registry.ModMenus;
import com.jaquadro.minecraft.gardencollection.registry.ModRecipeSerializers;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FireBlock;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;


@Mod(GardenCollection.MODID)
public class GardenCollection {
    public static final String MODID = "gardencollection";

    public GardenCollection() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        ModMenus.MENUS.register(bus);
        ModCreativeTabs.TABS.register(bus);
        ModRecipeSerializers.SERIALIZERS.register(bus);
        bus.addListener(this::commonSetup);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            CompostAPI.bootstrap();
            FireBlock fire = (FireBlock) Blocks.FIRE;
            for (String name : ModBlocks.ALL.keySet()) {
                if (name.startsWith("thin_log") || name.startsWith("wood_lattice") || name.startsWith("window_box_oak")
                        || name.startsWith("window_box_spruce") || name.startsWith("window_box_birch")
                        || name.startsWith("window_box_jungle") || name.startsWith("window_box_acacia")
                        || name.startsWith("window_box_dark_oak") || name.equals("charcoal_block") || name.equals("compost_bin")
                        || name.equals("ivy")) {
                    fire.setFlammable(ModBlocks.ALL.get(name).get(), 5, 20);
                }
            }
        });
    }
}
