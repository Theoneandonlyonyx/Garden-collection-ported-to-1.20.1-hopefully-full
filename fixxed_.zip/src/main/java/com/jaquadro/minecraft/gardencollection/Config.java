package com.jaquadro.minecraft.gardencollection;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

public final class Config {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue STRANGE_CHANCE;
    public static final ForgeConfigSpec.IntValue STRANGE_MIN;
    public static final ForgeConfigSpec.IntValue STRANGE_MAX;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> STRANGE_DROPS;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.comment("Strange Plant drop table. The 1.7.10 mod shipped this empty; these defaults make the plant useful in survival.")
                .push("strangePlant");
        STRANGE_CHANCE = builder.defineInRange("dropChance", 0.35D, 0.0D, 1.0D);
        STRANGE_MIN = builder.defineInRange("dropMin", 1, 0, 64);
        STRANGE_MAX = builder.defineInRange("dropMax", 1, 0, 64);
        STRANGE_DROPS = builder.defineList("drops", List.of(
                "minecraft:emerald",
                "minecraft:gold_nugget",
                "minecraft:ender_pearl",
                "minecraft:experience_bottle",
                "minecraft:diamond"
        ), o -> o instanceof String);
        builder.pop();
        SPEC = builder.build();
    }

    private Config() {}
}
