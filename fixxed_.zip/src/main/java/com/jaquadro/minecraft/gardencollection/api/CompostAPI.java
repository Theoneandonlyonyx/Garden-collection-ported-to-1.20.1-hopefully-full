package com.jaquadro.minecraft.gardencollection.api;

import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraftforge.common.IPlantable;

import java.util.HashMap;
import java.util.Map;

/**
 * Compost materials for the compost bin. Other mods can call this from their own common setup
 * (load after gardencollection) to register extra inputs.
 */
public final class CompostAPI {
    public record Material(int decomposeTicks, float yield) {}

    private static final Material DEFAULT = new Material(150, 0.125f);
    private static final Map<Item, Material> ITEMS = new HashMap<>();
    private static final Map<net.minecraft.tags.TagKey<Item>, Material> TAGS = new HashMap<>();
    private static final Map<Class<?>, Material> CLASSES = new HashMap<>();

    private CompostAPI() {}

    public static void register(Item item, int ticks, float yield) {
        if (item != null && item != Items.AIR) {
            ITEMS.put(item, new Material(Math.max(1, ticks), yield));
        }
    }

    public static void register(ItemStack stack, int ticks, float yield) {
        if (!stack.isEmpty()) {
            register(stack.getItem(), ticks, yield);
        }
    }

    public static void register(net.minecraft.tags.TagKey<Item> tag, int ticks, float yield) {
        TAGS.put(tag, new Material(Math.max(1, ticks), yield));
    }

    public static void registerClass(Class<?> type, int ticks, float yield) {
        CLASSES.put(type, new Material(Math.max(1, ticks), yield));
    }

    public static Material get(ItemStack stack) {
        if (stack.isEmpty()) {
            return null;
        }
        Material direct = ITEMS.get(stack.getItem());
        if (direct != null) {
            return direct;
        }
        for (Map.Entry<net.minecraft.tags.TagKey<Item>, Material> entry : TAGS.entrySet()) {
            if (stack.is(entry.getKey())) {
                return entry.getValue();
            }
        }
        if (stack.getItem() instanceof net.minecraft.world.item.BlockItem blockItem) {
            Block block = blockItem.getBlock();
            Material matched = matchClass(block.getClass());
            if (matched != null) {
                return matched;
            }
            if (block instanceof IPlantable) {
                Material plantable = CLASSES.get(IPlantable.class);
                if (plantable != null) {
                    return plantable;
                }
            }
        }
        if (stack.isEdible()) {
            return DEFAULT;
        }
        return matchClass(stack.getItem().getClass());
    }

    private static Material matchClass(Class<?> type) {
        while (type != null && type != Object.class) {
            Material material = CLASSES.get(type);
            if (material != null) {
                return material;
            }
            for (Class<?> iface : type.getInterfaces()) {
                Material fromIface = CLASSES.get(iface);
                if (fromIface != null) {
                    return fromIface;
                }
            }
            type = type.getSuperclass();
        }
        return null;
    }

    public static boolean isCompostable(ItemStack stack) {
        return get(stack) != null;
    }

    public static void bootstrap() {
        register(Blocks.MELON.asItem(), 150, 0.125f);
        register(Blocks.PUMPKIN.asItem(), 150, 0.125f);
        register(Blocks.HAY_BLOCK.asItem(), 150, 0.125f);
        register(Items.STRING, 100, 0.0625f);
        register(Items.WHEAT, 100, 0.125f);
        register(Items.SUGAR_CANE, 150, 0.125f);
        register(Items.FEATHER, 50, 0.0625f);
        register(Items.ROTTEN_FLESH, 150, 0.125f);
        register(Items.LEATHER, 150, 0.125f);
        register(ItemTags.LOGS, 300, 0.25f);
        register(ItemTags.LEAVES, 150, 0.125f);
        register(ItemTags.SAPLINGS, 150, 0.125f);
        register(Items.STICK, 150, 0.125f);
        registerClass(IPlantable.class, 150, 0.125f);
        registerClass(LeavesBlock.class, 150, 0.125f);
        registerClass(VineBlock.class, 150, 0.125f);
    }
}
