package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

/** Shared behaviour of every garden host block (ports of BlockGarden / BlockGardenProxy logic). */
public final class GardenHelper {
    private GardenHelper() {}

    // ---------------------------------------------------------------- item rules

    public static boolean isPlantItem(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        Block block = blockItem.getBlock();
        return block instanceof BushBlock || block instanceof CropBlock || block instanceof SaplingBlock
                || block instanceof DoublePlantBlock || block instanceof FlowerBlock || block instanceof StemBlock
                || block instanceof MushroomBlock || block instanceof NetherSproutsBlock || block instanceof RootsBlock
                || block instanceof SweetBerryBushBlock || block instanceof SeagrassBlock || block == Blocks.CACTUS
                || block == Blocks.SUGAR_CANE || block == Blocks.LILY_PAD || block == Blocks.BAMBOO;
    }

    /** Candles, lanterns, jack o'lanterns, pumpkins and melons may sit in beds, too. */
    public static boolean isDecorItem(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        Block block = blockItem.getBlock();
        return block instanceof CandleBlock || block instanceof net.minecraft.world.level.block.LanternBlock
                || block instanceof com.jaquadro.minecraft.gardencollection.block.LanternBlock
                || block instanceof CandelabraBlock || block instanceof CarvedPumpkinBlock
                || block == Blocks.PUMPKIN || block == Blocks.MELON;
    }

    /** Items that vanilla can plant on top of soil itself (seeds, stems, wart) are left to vanilla on soil blocks. */
    public static boolean acceptsOnSoil(ItemStack stack) {
        if (stack.getItem() instanceof BlockItem blockItem) {
            Block block = blockItem.getBlock();
            if (block instanceof CropBlock || block instanceof StemBlock || block instanceof NetherWartBlock || block instanceof SweetBerryBushBlock) {
                return false;
            }
        }
        return accepts(stack);
    }

    public static boolean accepts(ItemStack stack) {
        return isPlantItem(stack) || isDecorItem(stack);
    }

    // ---------------------------------------------------------------- interaction

    public static InteractionResult interact(Level level, BlockPos pos, Player player, InteractionHand hand) {
        if (!(level.getBlockEntity(pos) instanceof GardenBlockEntity garden)) {
            return InteractionResult.PASS;
        }
        ItemStack held = player.getItemInHand(hand);
        if (!held.isEmpty() && garden.getBlockState().getBlock() instanceof GardenPotBlock
                && net.minecraftforge.fluids.FluidUtil.interactWithFluidHandler(player, hand, level, pos, net.minecraft.core.Direction.UP)) {
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (held.isEmpty()) {
            for (int i = garden.slotCount() - 1; i >= 0; i--) {
                ItemStack plant = garden.getPlant(i);
                if (!plant.isEmpty()) {
                    if (!level.isClientSide) {
                        if (!player.addItem(plant.copy())) {
                            player.drop(plant.copy(), false);
                        }
                        garden.setPlant(i, ItemStack.EMPTY);
                    }
                    return InteractionResult.sidedSuccess(level.isClientSide);
                }
            }
            return InteractionResult.PASS;
        }
        if (!accepts(held)) {
            return InteractionResult.PASS;
        }
        for (int i = 0; i < garden.slotCount(); i++) {
            if (garden.getPlant(i).isEmpty()) {
                if (!level.isClientSide) {
                    ItemStack one = held.copy();
                    one.setCount(1);
                    garden.setPlant(i, one);
                    if (!player.getAbilities().instabuild) {
                        held.shrink(1);
                    }
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return InteractionResult.PASS;
    }

    public static void dropAll(Level level, BlockPos pos) {
        if (level.getBlockEntity(pos) instanceof GardenBlockEntity garden) {
            for (int i = 0; i < garden.slotCount(); i++) {
                Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), garden.getPlant(i));
            }
            BlockPos above = pos.above();
            if (level.getBlockState(above).getBlock() instanceof GardenProxyBlock) {
                level.setBlock(above, Blocks.AIR.defaultBlockState(), 3);
            }
        }
    }

    // ---------------------------------------------------------------- proxy binding

    /**
     * The proxy trick of the original mod: temporarily "bind" a stored plant state into the world
     * at the proxy position (the block above the host), let vanilla code run on it, then read the
     * result back into the slot and restore the proxy.
     */
    private static boolean bound(ServerLevel level, BlockPos host, GardenBlockEntity be, int slot, java.util.function.Consumer<BlockPos> action) {
        BlockState plant = be.getPlantState(slot);
        if (plant == null) {
            return false;
        }
        BlockPos pos = host.above();
        BlockState old = level.getBlockState(pos);
        if (!old.isAir() && !(old.getBlock() instanceof GardenProxyBlock)) {
            return false;
        }
        level.setBlock(pos, plant, 16 | 32);
        boolean changed = false;
        try {
            action.accept(pos);
            BlockState after = level.getBlockState(pos);
            if (after.getBlock() == plant.getBlock() && after != plant) {
                be.setPlantState(slot, after);
                changed = true;
            }
        } finally {
            level.setBlock(pos, old, 2 | 16 | 32);
        }
        return changed;
    }

    public static void randomTick(ServerLevel level, BlockPos host, net.minecraft.util.RandomSource random) {
        if (!(level.getBlockEntity(host) instanceof GardenBlockEntity be)) {
            return;
        }
        for (int i = 0; i < be.slotCount(); i++) {
            BlockState state = be.getPlantState(i);
            if (state == null || !(state.getBlock() instanceof CropBlock || state.getBlock() instanceof SweetBerryBushBlock
                    || state.getBlock() instanceof NetherWartBlock)) {
                continue;
            }
            bound(level, host, be, i, p -> level.getBlockState(p).randomTick(level, p, random));
        }
    }

    // ---------------------------------------------------------------- bonemeal

    private static boolean growable(BlockState state) {
        Block block = state.getBlock();
        if (block instanceof SaplingBlock || block instanceof DoublePlantBlock) {
            return false;
        }
        return block == Blocks.GRASS || block == Blocks.FERN || block instanceof BonemealableBlock;
    }

    public static boolean canBonemeal(LevelReader level, BlockPos host, boolean client) {
        if (!(level.getBlockEntity(host) instanceof GardenBlockEntity be)) {
            return false;
        }
        for (int i = 0; i < be.slotCount(); i++) {
            BlockState state = be.getPlantState(i);
            if (state == null || !growable(state)) {
                continue;
            }
            if (state.getBlock() == Blocks.GRASS || state.getBlock() == Blocks.FERN) {
                return true;
            }
            if (((BonemealableBlock) state.getBlock()).isValidBonemealTarget(level, host.above(), state, client)) {
                return true;
            }
        }
        return false;
    }

    public static void applyBonemeal(ServerLevel level, BlockPos host, net.minecraft.util.RandomSource random) {
        if (!(level.getBlockEntity(host) instanceof GardenBlockEntity be)) {
            return;
        }
        for (int i = 0; i < be.slotCount(); i++) {
            BlockState state = be.getPlantState(i);
            if (state == null || !growable(state)) {
                continue;
            }
            Block block = state.getBlock();
            if (block == Blocks.GRASS || block == Blocks.FERN) {
                be.setPlant(i, new ItemStack(block == Blocks.GRASS ? Items.TALL_GRASS : Items.LARGE_FERN));
                continue;
            }
            BonemealableBlock growable = (BonemealableBlock) block;
            if (!growable.isValidBonemealTarget(level, host.above(), state, false)) {
                continue;
            }
            final int slot = i;
            bound(level, host, be, slot, p -> {
                BlockState cur = level.getBlockState(p);
                if (growable.isBonemealSuccess(level, random, p, cur)) {
                    growable.performBonemeal(level, random, p, cur);
                }
            });
        }
    }

    public static DoubleBlockHalf upper() {
        return DoubleBlockHalf.UPPER;
    }

    @SuppressWarnings("unused")
    private static Block unused() {
        return ModBlocks.GARDEN_SOIL.get();
    }
}
