package com.jaquadro.minecraft.gardencollection.block;

/** Any block that carries a GardenBlockEntity (pots, window boxes, garden soil, tilled soil). */
public interface GardenHost {
    /** Light emitted by whatever is in the host (lanterns, candles, jack o'lanterns, lava...). */
    net.minecraft.world.level.block.state.properties.IntegerProperty LIGHT =
            net.minecraft.world.level.block.state.properties.IntegerProperty.create("light", 0, 15);

    int gardenSlots();

    /** Height (0..1) of the surface plants stand on. */
    double plantTop();
}
