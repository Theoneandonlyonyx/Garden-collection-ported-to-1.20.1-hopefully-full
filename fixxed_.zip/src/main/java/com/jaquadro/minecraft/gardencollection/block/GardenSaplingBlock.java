package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.grower.AbstractTreeGrower;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.material.MapColor;
import org.jetbrains.annotations.Nullable;

/** Sapling that grows one of the Garden Trees configured features (data/gardencollection/worldgen). */
public class GardenSaplingBlock extends SaplingBlock {
    public enum Kind {
        PINE("pine_tree"),
        SWAMP("swamp_tree"),
        TALL_BIRCH("tall_birch_tree");

        private final String feature;

        Kind(String feature) {
            this.feature = feature;
        }

        AbstractTreeGrower grower() {
            final ResourceKey<ConfiguredFeature<?, ?>> key = ResourceKey.create(Registries.CONFIGURED_FEATURE, new ResourceLocation(GardenCollection.MODID, feature));
            return new AbstractTreeGrower() {
                @Nullable
                @Override
                protected ResourceKey<ConfiguredFeature<?, ?>> getConfiguredFeature(RandomSource random, boolean hasFlowers) {
                    return key;
                }
            };
        }
    }

    private final Kind kind;

    public GardenSaplingBlock(Kind kind) {
        super(kind.grower(), Properties.of().mapColor(MapColor.PLANT).noCollission().randomTicks().instabreak().sound(SoundType.GRASS));
        this.kind = kind;
    }

    public Kind kind() {
        return kind;
    }
}
