package com.jaquadro.minecraft.gardencollection.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class HoopBlock extends Block {
    private static final VoxelShape SHAPE = Shapes.or(
            box(2, 0, 7, 14, 1, 9),
            box(2, 15, 7, 14, 16, 9),
            box(2, 1, 7, 3, 15, 9),
            box(13, 1, 7, 14, 15, 9)
    );

    public HoopBlock() {
        super(Properties.of().mapColor(MapColor.METAL).strength(3.0F, 6.0F).sound(net.minecraft.world.level.block.SoundType.METAL).noOcclusion().requiresCorrectToolForDrops());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }
}
