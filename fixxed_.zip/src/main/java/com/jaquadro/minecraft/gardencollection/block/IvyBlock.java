package com.jaquadro.minecraft.gardencollection.block;

import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.material.MapColor;

public class IvyBlock extends VineBlock {
    public IvyBlock() {
        super(Properties.of().mapColor(MapColor.PLANT).replaceable().noCollission().randomTicks().strength(0.2F).sound(net.minecraft.world.level.block.SoundType.VINE).ignitedByLava());
    }
}
