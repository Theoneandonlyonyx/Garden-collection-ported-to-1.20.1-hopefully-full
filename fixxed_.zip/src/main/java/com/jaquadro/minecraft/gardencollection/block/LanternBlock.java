package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.block.entity.LanternBlockEntity;
import com.jaquadro.minecraft.gardencollection.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.StainedGlassPaneBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public class LanternBlock extends BaseEntityBlock implements SimpleWaterloggedBlock {
    public static final BooleanProperty HANGING = BooleanProperty.create("hanging");
    public static final BooleanProperty WATERLOGGED = BooleanProperty.create("waterlogged");
    /** 0 none, 1 clear, 2-17 dyed (DyeColor id + 2). */
    public static final IntegerProperty GLASS = IntegerProperty.create("glass", 0, 17);
    public static final IntegerProperty LIGHT = IntegerProperty.create("light", 0, 15);

    private static final VoxelShape STANDING = Block.box(4, 0, 4, 12, 12, 12);
    private static final VoxelShape HANG = Block.box(4, 2, 4, 12, 16, 12);

    public LanternBlock() {
        super(Properties.of().mapColor(MapColor.METAL).strength(2.5F, 5.0F).sound(SoundType.LANTERN).noOcclusion()
                .lightLevel(state -> state.getValue(LIGHT)));
        registerDefaultState(defaultBlockState().setValue(HANGING, false).setValue(WATERLOGGED, false).setValue(GLASS, 0).setValue(LIGHT, 0));
    }

    @Override public RenderShape getRenderShape(BlockState state) { return RenderShape.MODEL; }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return state.getValue(HANGING) ? HANG : STANDING;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new LanternBlockEntity(pos, state); }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        boolean hanging = context.getClickedFace() == Direction.DOWN;
        FluidState fluid = context.getLevel().getFluidState(context.getClickedPos());
        return defaultBlockState().setValue(HANGING, hanging).setValue(WATERLOGGED, fluid.getType() == Fluids.WATER);
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        if (state.getValue(HANGING)) {
            return level.getBlockState(pos.above()).isFaceSturdy(level, pos.above(), Direction.DOWN)
                    || level.getBlockState(pos.above()).is(net.minecraft.tags.BlockTags.FENCES);
        }
        return level.getBlockState(pos.below()).isFaceSturdy(level, pos.below(), Direction.UP);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighbor, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (state.getValue(WATERLOGGED)) {
            level.scheduleTick(pos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
        }
        return !canSurvive(state, level, pos) ? Blocks.AIR.defaultBlockState() : super.updateShape(state, direction, neighbor, level, pos, neighborPos);
    }

    @Override
    public FluidState getFluidState(BlockState state) {
        return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof LanternBlockEntity lantern)) return InteractionResult.PASS;
        ItemStack held = player.getItemInHand(hand);
        if (held.isEmpty() && player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                ItemStack source = lantern.extractSource();
                if (!source.isEmpty()) {
                    if (!player.addItem(source)) player.drop(source, false);
                    level.setBlock(pos, state.setValue(LIGHT, 0), 3);
                } else if (state.getValue(GLASS) != 0) {
                    level.setBlock(pos, state.setValue(GLASS, 0), 3);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        int glass = glassOf(held);
        if (glass >= 0) {
            if (!level.isClientSide) {
                level.setBlock(pos, state.setValue(GLASS, glass), 3);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        int light = lightOf(held);
        if (light > 0 && lantern.getSource().isEmpty()) {
            if (!level.isClientSide) {
                ItemStack one = held.copy();
                one.setCount(1);
                lantern.setSource(one);
                if (!player.getAbilities().instabuild) held.shrink(1);
                level.setBlock(pos, state.setValue(LIGHT, light), 3);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }

    public static int glassOf(ItemStack stack) {
        if (stack.is(Items.GLASS_PANE)) return 1;
        if (stack.getItem() instanceof net.minecraft.world.item.BlockItem blockItem && blockItem.getBlock() instanceof StainedGlassPaneBlock pane) {
            return pane.getColor().getId() + 2;
        }
        return -1;
    }

    public static int lightOf(ItemStack stack) {
        if (stack.is(Items.TORCH) || stack.is(Items.LANTERN)) return 14;
        if (stack.is(Items.SOUL_TORCH) || stack.is(Items.SOUL_LANTERN)) return 10;
        if (stack.is(Items.REDSTONE_TORCH)) return 7;
        if (stack.is(Items.GLOWSTONE)) return 15;
        if (stack.is(Items.CANDLE) || stack.is(ModItems.CANDLE.get())) return 12;
        if (stack.is(Items.SEA_LANTERN) || stack.is(Items.GLOWSTONE_DUST) && false) return 15;
        return 0;
    }

    public static int dyeTint(BlockState state) {
        int glass = state.getValue(GLASS);
        if (glass < 2) return -1;
        return DyeColor.byId(glass - 2).getFireworkColor();
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof LanternBlockEntity lantern) {
            Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), lantern.getSource());
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(HANGING, WATERLOGGED, GLASS, LIGHT);
    }
}
