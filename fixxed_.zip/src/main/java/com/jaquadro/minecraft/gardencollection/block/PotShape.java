package com.jaquadro.minecraft.gardencollection.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.shapes.VoxelShape;

public enum PotShape {
    LARGE(Block.box(2, 0, 2, 14, 12, 14)),
    MEDIUM(Block.box(4, 0, 4, 12, 9, 12)),
    DECORATIVE(Block.box(3, 0, 3, 13, 11, 13));

    public final VoxelShape shape;

    PotShape(VoxelShape shape) {
        this.shape = shape;
    }
}
