package com.jaquadro.minecraft.gardencollection.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Unfired clay pot. Smelt it to get the finished pot. */
public class RawPotBlock extends Block {
    public RawPotBlock() {
        super(Properties.of().mapColor(MapColor.CLAY).strength(0.5F).sound(SoundType.GRAVEL).noOcclusion());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return PotShape.LARGE.shape;
    }
}
