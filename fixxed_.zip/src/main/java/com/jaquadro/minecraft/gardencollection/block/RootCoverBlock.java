package com.jaquadro.minecraft.gardencollection.block;

import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.CarpetBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;

public class RootCoverBlock extends CarpetBlock {
    public RootCoverBlock() {
        super(Properties.of().mapColor(MapColor.PODZOL).strength(0.1F).sound(net.minecraft.world.level.block.SoundType.ROOTS).noOcclusion());
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState();
    }
}
