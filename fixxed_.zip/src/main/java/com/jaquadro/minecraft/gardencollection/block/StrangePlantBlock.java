package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.Config;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraftforge.registries.ForgeRegistries;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class StrangePlantBlock extends FlowerBlock {
    public StrangePlantBlock() {
        super(MobEffects.LUCK, 8, Properties.copy(net.minecraft.world.level.block.Blocks.POPPY));
    }

    @Override
    public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
        List<ItemStack> drops = new ArrayList<>();
        ItemStack tool = builder.getOptionalParameter(LootContextParams.TOOL);
        if (tool != null && tool.is(Items.SHEARS)) {
            drops.add(new ItemStack(this));
            return drops;
        }
        var level = builder.getLevel();
        if (level.getRandom().nextDouble() > Config.STRANGE_CHANCE.get()) {
            return drops;
        }
        List<? extends String> ids = Config.STRANGE_DROPS.get();
        if (ids.isEmpty()) {
            return drops;
        }
        int min = Config.STRANGE_MIN.get();
        int max = Math.max(min, Config.STRANGE_MAX.get());
        int count = min + (max > min ? level.getRandom().nextInt(max - min + 1) : 0);
        String id = ids.get(level.getRandom().nextInt(ids.size()));
        Item item = ForgeRegistries.ITEMS.getValue(new net.minecraft.resources.ResourceLocation(id));
        if (item == null || item == Items.AIR || count <= 0) {
            return drops;
        }
        drops.add(new ItemStack(item, count));
        return drops;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable BlockGetter level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("block.gardencollection.strange_plant.desc"));
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        return super.canSurvive(state, level, pos);
    }
}
