package com.jaquadro.minecraft.gardencollection.block.entity;

import com.jaquadro.minecraft.gardencollection.block.BloomeryFurnaceBlock;
import com.jaquadro.minecraft.gardencollection.inventory.BloomeryMenu;
import com.jaquadro.minecraft.gardencollection.registry.ModBlockEntities;
import com.jaquadro.minecraft.gardencollection.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public class BloomeryBlockEntity extends BaseContainerBlockEntity implements WorldlyContainer {
    public static final int PRIMARY = 0;
    public static final int SECONDARY = 1;
    public static final int FUEL = 2;
    public static final int OUTPUT = 3;
    private static final int[] SLOTS = {0, 1, 2, 3};

    private NonNullList<ItemStack> items = NonNullList.withSize(4, ItemStack.EMPTY);
    private int burnTime;
    private int burnDuration;
    private int cookTime;

    private final ContainerData data = new ContainerData() {
        @Override public int get(int index) {
            return switch (index) {
                case 0 -> burnTime;
                case 1 -> burnDuration;
                case 2 -> cookTime;
                default -> 0;
            };
        }
        @Override public void set(int index, int value) {
            switch (index) {
                case 0 -> burnTime = value;
                case 1 -> burnDuration = value;
                case 2 -> cookTime = value;
                default -> {}
            }
        }
        @Override public int getCount() { return 3; }
    };

    public BloomeryBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.BLOOMERY.get(), pos, state);
    }

    public ContainerData data() { return data; }

    public static void serverTick(net.minecraft.world.level.Level level, BlockPos pos, BlockState state, BloomeryBlockEntity be) {
        boolean wasBurning = be.burnTime > 0;
        boolean dirty = false;
        if (be.burnTime > 0) be.burnTime--;
        if (be.burnTime == 0 && be.canSmelt()) {
            be.burnDuration = be.burnTime = burnTimeOf(be.items.get(FUEL));
            if (be.burnTime > 0) {
                dirty = true;
                ItemStack fuel = be.items.get(FUEL);
                if (!fuel.isEmpty()) {
                    ItemStack container = fuel.getCraftingRemainingItem();
                    fuel.shrink(1);
                    if (fuel.isEmpty()) be.items.set(FUEL, container);
                }
            }
        }
        if (be.burnTime > 0 && be.canSmelt()) {
            be.cookTime++;
            if (be.cookTime >= 200) {
                be.cookTime = 0;
                be.smelt();
                dirty = true;
            }
        } else {
            be.cookTime = 0;
        }
        if (wasBurning != be.burnTime > 0) {
            dirty = true;
            level.setBlock(pos, state.setValue(BloomeryFurnaceBlock.LIT, be.burnTime > 0), 3);
        }
        if (dirty) be.setChanged();
    }

    private boolean canSmelt() {
        if (!isPrimary(items.get(PRIMARY)) || !isSecondary(items.get(SECONDARY))) return false;
        ItemStack out = items.get(OUTPUT);
        if (out.isEmpty()) return true;
        if (!out.is(ModItems.WROUGHT_IRON_INGOT.get())) return false;
        return out.getCount() < out.getMaxStackSize();
    }

    private void smelt() {
        if (!canSmelt()) return;
        ItemStack out = items.get(OUTPUT);
        if (out.isEmpty()) items.set(OUTPUT, new ItemStack(ModItems.WROUGHT_IRON_INGOT.get()));
        else out.grow(1);
        items.get(PRIMARY).shrink(1);
        items.get(SECONDARY).shrink(1);
        if (items.get(PRIMARY).isEmpty()) items.set(PRIMARY, ItemStack.EMPTY);
        if (items.get(SECONDARY).isEmpty()) items.set(SECONDARY, ItemStack.EMPTY);
    }

    public static boolean isPrimary(ItemStack stack) {
        return stack.is(Items.IRON_INGOT) || stack.is(Items.RAW_IRON) || stack.is(Blocks.IRON_ORE.asItem()) || stack.is(Blocks.DEEPSLATE_IRON_ORE.asItem());
    }

    public static boolean isSecondary(ItemStack stack) {
        return stack.is(Blocks.SAND.asItem()) || stack.is(Blocks.RED_SAND.asItem());
    }

    public static int burnTimeOf(ItemStack stack) {
        if (stack.is(Items.CHARCOAL)) return 1600;
        if (stack.is(com.jaquadro.minecraft.gardencollection.registry.ModBlocks.CHARCOAL_BLOCK.get().asItem())) return 16000;
        return 0;
    }

    @Override protected Component getDefaultName() {
        return Component.translatable("container.gardencollection.bloomery_furnace");
    }

    @Override protected AbstractContainerMenu createMenu(int id, Inventory inventory) {
        return new BloomeryMenu(id, inventory, this, data);
    }

    @Override public int getContainerSize() { return 4; }
    @Override public boolean isEmpty() {
        for (ItemStack stack : items) if (!stack.isEmpty()) return false;
        return true;
    }
    @Override public ItemStack getItem(int slot) { return items.get(slot); }
    @Override public ItemStack removeItem(int slot, int amount) {
        ItemStack result = ContainerHelper.removeItem(items, slot, amount);
        if (!result.isEmpty()) setChanged();
        return result;
    }
    @Override public ItemStack removeItemNoUpdate(int slot) { return ContainerHelper.takeItem(items, slot); }
    @Override public void setItem(int slot, ItemStack stack) {
        items.set(slot, stack);
        if (stack.getCount() > getMaxStackSize()) stack.setCount(getMaxStackSize());
        setChanged();
    }
    @Override public boolean stillValid(Player player) { return net.minecraft.world.Container.stillValidBlockEntity(this, player); }
    @Override public void clearContent() { items.clear(); }
    @Override public int[] getSlotsForFace(Direction side) { return SLOTS; }
    @Override public boolean canPlaceItemThroughFace(int index, ItemStack stack, @Nullable Direction dir) { return canPlaceItem(index, stack); }
    @Override public boolean canTakeItemThroughFace(int index, ItemStack stack, Direction dir) { return index == OUTPUT; }
    @Override public boolean canPlaceItem(int index, ItemStack stack) {
        if (index == OUTPUT) return false;
        if (index == FUEL) return burnTimeOf(stack) > 0;
        if (index == PRIMARY) return isPrimary(stack);
        if (index == SECONDARY) return isSecondary(stack);
        return false;
    }

    @Override protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ContainerHelper.saveAllItems(tag, items);
        tag.putInt("Burn", burnTime);
        tag.putInt("BurnDur", burnDuration);
        tag.putInt("Cook", cookTime);
    }

    @Override public void load(CompoundTag tag) {
        super.load(tag);
        items = NonNullList.withSize(4, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, items);
        burnTime = tag.getInt("Burn");
        burnDuration = tag.getInt("BurnDur");
        cookTime = tag.getInt("Cook");
    }
}
