package com.jaquadro.minecraft.gardencollection.block.entity;

import com.jaquadro.minecraft.gardencollection.api.CompostAPI;
import com.jaquadro.minecraft.gardencollection.inventory.CompostBinMenu;
import com.jaquadro.minecraft.gardencollection.registry.ModBlockEntities;
import com.jaquadro.minecraft.gardencollection.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public class CompostBinBlockEntity extends BaseContainerBlockEntity implements WorldlyContainer {
    public static final int SLOTS = 10;
    public static final int OUTPUT = 9;
    private static final int[] INPUTS = {0, 1, 2, 3, 4, 5, 6, 7, 8};
    private static final int[] OUTPUTS = {OUTPUT};

    private NonNullList<ItemStack> items = NonNullList.withSize(SLOTS, ItemStack.EMPTY);
    private int decomposeTime;
    private int currentDecomposeTime;
    private int decomposeCount;
    private int currentSlot = -1;

    private final ContainerData data = new ContainerData() {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> decomposeTime;
                case 1 -> currentDecomposeTime;
                case 2 -> decomposeCount;
                default -> 0;
            };
        }

        @Override
        public void set(int index, int value) {
            switch (index) {
                case 0 -> decomposeTime = value;
                case 1 -> currentDecomposeTime = value;
                case 2 -> decomposeCount = value;
                default -> {
                }
            }
        }

        @Override
        public int getCount() {
            return 3;
        }
    };

    public CompostBinBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.COMPOST_BIN.get(), pos, state);
    }

    public static void serverTick(net.minecraft.world.level.Level level, BlockPos pos, BlockState state, CompostBinBlockEntity bin) {
        boolean wasWorking = bin.decomposeTime > 0;
        if (bin.decomposeTime > 0) {
            bin.decomposeTime--;
        }
        if (bin.decomposeTime == 0) {
            if (bin.currentSlot >= 0 && bin.canCompost()) {
                bin.finishOne();
            }
            bin.currentSlot = bin.pickSlot();
            if (bin.currentSlot >= 0 && bin.outputHasRoom()) {
                CompostAPI.Material material = CompostAPI.get(bin.items.get(bin.currentSlot));
                bin.currentDecomposeTime = material == null ? 0 : material.decomposeTicks();
                bin.decomposeTime = bin.currentDecomposeTime;
            } else {
                bin.currentDecomposeTime = 0;
            }
        }
        if (wasWorking != bin.decomposeTime > 0) {
            level.sendBlockUpdated(pos, state, state, 3);
        }
        bin.setChanged();
    }

    private boolean outputHasRoom() {
        ItemStack out = items.get(OUTPUT);
        return out.isEmpty() || (out.is(ModItems.COMPOST.get()) && out.getCount() < out.getMaxStackSize());
    }

    private boolean canCompost() {
        if (currentSlot < 0 || currentSlot >= OUTPUT) return false;
        ItemStack stack = items.get(currentSlot);
        return !stack.isEmpty() && CompostAPI.isCompostable(stack) && outputHasRoom();
    }

    private void finishOne() {
        if (!canCompost()) return;
        if (decomposeCount < 8) decomposeCount++;
        if (decomposeCount >= 8) {
            ItemStack out = items.get(OUTPUT);
            if (out.isEmpty()) items.set(OUTPUT, new ItemStack(ModItems.COMPOST.get()));
            else out.grow(1);
            decomposeCount = 0;
        }
        ItemStack in = items.get(currentSlot);
        in.shrink(1);
        if (in.isEmpty()) items.set(currentSlot, ItemStack.EMPTY);
        currentSlot = -1;
    }

    private int pickSlot() {
        int filled = 0;
        for (int i = 0; i < OUTPUT; i++) if (!items.get(i).isEmpty()) filled++;
        if (filled == 0 || level == null) return -1;
        int index = level.getRandom().nextInt(filled);
        for (int i = 0, c = 0; i < OUTPUT; i++) {
            if (!items.get(i).isEmpty() && c++ == index) return i;
        }
        return -1;
    }

    public ContainerData data() {
        return data;
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.gardencollection.compost_bin");
    }

    @Override
    protected AbstractContainerMenu createMenu(int id, Inventory inventory) {
        return new CompostBinMenu(id, inventory, this, data);
    }

    @Override
    public int getContainerSize() {
        return SLOTS;
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : items) if (!stack.isEmpty()) return false;
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack result = ContainerHelper.removeItem(items, slot, amount);
        if (!result.isEmpty()) setChanged();
        return result;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        items.set(slot, stack);
        if (stack.getCount() > getMaxStackSize()) stack.setCount(getMaxStackSize());
        setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValidBlockEntity(this, player);
    }

    private static boolean stillValidBlockEntity(CompostBinBlockEntity be, Player player) {
        return net.minecraft.world.Container.stillValidBlockEntity(be, player);
    }

    @Override
    public void clearContent() {
        items.clear();
    }

    @Override
    public int[] getSlotsForFace(Direction side) {
        return side == Direction.DOWN ? OUTPUTS : INPUTS;
    }

    @Override
    public boolean canPlaceItemThroughFace(int index, ItemStack stack, @Nullable Direction dir) {
        return index < OUTPUT && CompostAPI.isCompostable(stack);
    }

    @Override
    public boolean canTakeItemThroughFace(int index, ItemStack stack, Direction dir) {
        return index == OUTPUT && stack.is(ModItems.COMPOST.get());
    }

    @Override
    public boolean canPlaceItem(int index, ItemStack stack) {
        return index < OUTPUT && CompostAPI.isCompostable(stack);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ContainerHelper.saveAllItems(tag, items);
        tag.putInt("DecompTime", decomposeTime);
        tag.putInt("CurrentTime", currentDecomposeTime);
        tag.putInt("DecompCount", decomposeCount);
        tag.putInt("DecompSlot", currentSlot);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        items = NonNullList.withSize(SLOTS, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, items);
        decomposeTime = tag.getInt("DecompTime");
        currentDecomposeTime = tag.getInt("CurrentTime");
        decomposeCount = tag.getInt("DecompCount");
        currentSlot = tag.getInt("DecompSlot");
    }
}
