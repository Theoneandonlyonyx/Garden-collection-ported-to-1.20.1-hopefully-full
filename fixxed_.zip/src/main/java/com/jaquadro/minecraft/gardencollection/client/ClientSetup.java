package com.jaquadro.minecraft.gardencollection.client;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import com.jaquadro.minecraft.gardencollection.block.LanternBlock;
import com.jaquadro.minecraft.gardencollection.client.renderer.GardenBlockEntityRenderer;
import com.jaquadro.minecraft.gardencollection.client.screen.BloomeryScreen;
import com.jaquadro.minecraft.gardencollection.client.screen.CompostBinScreen;
import com.jaquadro.minecraft.gardencollection.client.screen.GardenScreen;
import com.jaquadro.minecraft.gardencollection.client.screen.PotteryTableScreen;
import com.jaquadro.minecraft.gardencollection.registry.ModBlockEntities;
import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import com.jaquadro.minecraft.gardencollection.registry.ModMenus;
import com.jaquadro.minecraft.gardencollection.item.PotteryPatternItem;
import com.jaquadro.minecraft.gardencollection.registry.ModItems;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.FoliageColor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = GardenCollection.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            MenuScreens.register(ModMenus.GARDEN.get(), GardenScreen::new);
            MenuScreens.register(ModMenus.COMPOST_BIN.get(), CompostBinScreen::new);
            MenuScreens.register(ModMenus.BLOOMERY.get(), BloomeryScreen::new);
            MenuScreens.register(ModMenus.POTTERY_TABLE.get(), PotteryTableScreen::new);
            ItemProperties.register(ModItems.POTTERY_PATTERN.get(), new ResourceLocation(GardenCollection.MODID, "pattern"),
                    (stack, level, entity, seed) -> PotteryPatternItem.patternOf(stack) / 13.0F);
        });
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.GARDEN.get(), GardenBlockEntityRenderer::new);
    }

    @SubscribeEvent
    public static void onBlockColors(RegisterColorHandlersEvent.Block event) {
        // tint index 1 on the lantern glass element follows the dyed glass pane
        event.register((state, level, pos, tintIndex) -> tintIndex == 1 ? LanternBlock.dyeTint(state) : -1, ModBlocks.LANTERN.get());
    }

    @SubscribeEvent
    public static void onIvyBlockColor(RegisterColorHandlersEvent.Block event) {
        event.register((state, level, pos, tintIndex) -> level != null && pos != null
                ? BiomeColors.getAverageFoliageColor(level, pos) : FoliageColor.getDefaultColor(), ModBlocks.IVY.get());
    }

    @SubscribeEvent
    public static void onIvyItemColor(RegisterColorHandlersEvent.Item event) {
        event.register((stack, tintIndex) -> FoliageColor.getDefaultColor(), ModBlocks.IVY.get().asItem());
    }
}
