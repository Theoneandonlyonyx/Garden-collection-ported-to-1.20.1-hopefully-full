package com.jaquadro.minecraft.gardencollection.client.renderer;

import com.jaquadro.minecraft.gardencollection.block.GardenHost;
import com.jaquadro.minecraft.gardencollection.block.WindowBoxBlock;
import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.phys.AABB;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.core.Direction;
import net.minecraftforge.client.extensions.common.IClientFluidTypeExtensions;
import net.minecraftforge.fluids.FluidStack;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

/** Draws the plants and decor that sit in a pot / window box / soil block. */
public class GardenBlockEntityRenderer implements BlockEntityRenderer<GardenBlockEntity> {
    private final BlockRenderDispatcher blockRenderer;

    public GardenBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
        this.blockRenderer = context.getBlockRenderDispatcher();
    }

    @Override
    public void render(GardenBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers, int light, int overlay) {
        BlockState hostState = be.getBlockState();
        if (!(hostState.getBlock() instanceof GardenHost host)) {
            return;
        }
        int count = be.slotCount();
        double top = host.plantTop();

        FluidStack fluid = be.tank().getFluid();
        if (!fluid.isEmpty() && hostState.getBlock() instanceof com.jaquadro.minecraft.gardencollection.block.GardenPotBlock potBlock) {
            AABB box = potBlock instanceof WindowBoxBlock ? hostState.getShape(be.getLevel(), be.getBlockPos()).bounds() : potBlock.potShape().shape.bounds();
            drawFluid(fluid, box, top + 0.01D, pose, buffers, light);
        }

        for (int i = 0; i < count; i++) {
            BlockState state = be.getRenderState(i);
            if (state == null) {
                continue;
            }
            double[] p = position(hostState, count, i);
            float scale = (float) p[2];
            pose.pushPose();
            pose.translate(p[0] - scale / 2.0D, top, p[1] - scale / 2.0D);
            pose.scale(scale, scale, scale);
            blockRenderer.renderSingleBlock(state, pose, buffers, light, overlay);
            if (state.getBlock() instanceof DoublePlantBlock && state.hasProperty(DoublePlantBlock.HALF)) {
                pose.translate(0.0D, 1.0D, 0.0D);
                blockRenderer.renderSingleBlock(state.setValue(DoublePlantBlock.HALF, DoubleBlockHalf.UPPER), pose, buffers, light, overlay);
            }
            pose.popPose();
        }
    }

    private static void drawFluid(FluidStack fluid, AABB box, double y, PoseStack pose, MultiBufferSource buffers, int light) {
        IClientFluidTypeExtensions ext = IClientFluidTypeExtensions.of(fluid.getFluid());
        TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(ext.getStillTexture(fluid));
        int color = ext.getTintColor(fluid);
        float a = ((color >> 24) & 255) / 255.0F;
        float r = ((color >> 16) & 255) / 255.0F;
        float g = ((color >> 8) & 255) / 255.0F;
        float b = (color & 255) / 255.0F;
        if (a == 0.0F) {
            a = 1.0F;
        }
        float x0 = (float) box.minX + 0.0625F, x1 = (float) box.maxX - 0.0625F;
        float z0 = (float) box.minZ + 0.0625F, z1 = (float) box.maxZ - 0.0625F;
        float yy = (float) y;
        float u0 = sprite.getU(x0 * 16.0F), u1 = sprite.getU(x1 * 16.0F);
        float v0 = sprite.getV(z0 * 16.0F), v1 = sprite.getV(z1 * 16.0F);
        VertexConsumer vc = buffers.getBuffer(RenderType.translucent());
        Matrix4f m = pose.last().pose();
        Matrix3f n = pose.last().normal();
        vc.vertex(m, x0, yy, z0).color(r, g, b, a).uv(u0, v0).uv2(light).normal(n, 0, 1, 0).endVertex();
        vc.vertex(m, x0, yy, z1).color(r, g, b, a).uv(u0, v1).uv2(light).normal(n, 0, 1, 0).endVertex();
        vc.vertex(m, x1, yy, z1).color(r, g, b, a).uv(u1, v1).uv2(light).normal(n, 0, 1, 0).endVertex();
        vc.vertex(m, x1, yy, z0).color(r, g, b, a).uv(u1, v0).uv2(light).normal(n, 0, 1, 0).endVertex();
    }

    /** x, z centre and scale for a slot. */
    private static double[] position(BlockState state, int count, int index) {
        if (state.getBlock() instanceof WindowBoxBlock) {
            Direction facing = state.getValue(WindowBoxBlock.FACING);
            double across = (facing == Direction.NORTH || facing == Direction.WEST) ? 0.19D : 0.81D;
            double along = 0.2D + 0.3D * index;
            return facing.getAxis() == Direction.Axis.X ? new double[]{across, along, 0.5D} : new double[]{along, across, 0.5D};
        }
        if (count == 1) {
            return new double[]{0.5D, 0.5D, 0.75D};
        }
        double[][] cells = {{0.28D, 0.28D}, {0.72D, 0.28D}, {0.28D, 0.72D}, {0.72D, 0.72D}};
        return new double[]{cells[index][0], cells[index][1], 0.42D};
    }
}
