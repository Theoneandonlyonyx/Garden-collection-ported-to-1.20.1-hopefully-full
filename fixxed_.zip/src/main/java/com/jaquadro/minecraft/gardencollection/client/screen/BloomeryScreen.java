package com.jaquadro.minecraft.gardencollection.client.screen;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import com.jaquadro.minecraft.gardencollection.inventory.BloomeryMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class BloomeryScreen extends AbstractContainerScreen<BloomeryMenu> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(GardenCollection.MODID, "textures/gui/bloomery_furnace.png");

    public BloomeryScreen(BloomeryMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 166;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
        if (menu.isBurning()) {
            int flame = menu.getBurnScaled(13);
            graphics.blit(TEXTURE, leftPos + 56, topPos + 36 + 12 - flame, 176, 12 - flame, 14, flame + 1);
        }
        int cook = menu.getCookScaled(24);
        graphics.blit(TEXTURE, leftPos + 79, topPos + 34, 176, 14, cook + 1, 16);
    }
}
