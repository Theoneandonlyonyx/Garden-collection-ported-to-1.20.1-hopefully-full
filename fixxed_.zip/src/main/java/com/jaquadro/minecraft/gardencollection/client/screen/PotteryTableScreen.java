package com.jaquadro.minecraft.gardencollection.client.screen;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import com.jaquadro.minecraft.gardencollection.inventory.PotteryTableMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class PotteryTableScreen extends AbstractContainerScreen<PotteryTableMenu> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(GardenCollection.MODID, "textures/gui/pottery_table.png");

    public PotteryTableScreen(PotteryTableMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 222;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
    }
}
