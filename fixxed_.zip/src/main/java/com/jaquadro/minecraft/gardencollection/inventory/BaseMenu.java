package com.jaquadro.minecraft.gardencollection.inventory;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;

/** Shared helper so menus can add the player inventory (addSlot is protected). */
public abstract class BaseMenu extends AbstractContainerMenu {
    protected BaseMenu(MenuType<?> type, int id) {
        super(type, id);
    }

    protected void addPlayerSlots(Inventory inv, int x, int y) {
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inv, col + row * 9 + 9, x + col * 18, y + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inv, col, x + col * 18, y + 58));
        }
    }
}
