package com.jaquadro.minecraft.gardencollection.inventory;

import com.jaquadro.minecraft.gardencollection.api.CompostAPI;
import com.jaquadro.minecraft.gardencollection.block.entity.CompostBinBlockEntity;
import com.jaquadro.minecraft.gardencollection.registry.ModMenus;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class CompostBinMenu extends BaseMenu {
    private final CompostBinBlockEntity bin;
    private final ContainerData data;

    public CompostBinMenu(int id, Inventory playerInv, FriendlyByteBuf buf) {
        this(id, playerInv, (CompostBinBlockEntity) playerInv.player.level().getBlockEntity(buf.readBlockPos()), new SimpleContainerData(3));
    }

    public CompostBinMenu(int id, Inventory playerInv, CompostBinBlockEntity bin, ContainerData data) {
        super(ModMenus.COMPOST_BIN.get(), id);
        this.bin = bin;
        this.data = data;
        for (int y = 0; y < 3; y++) {
            for (int x = 0; x < 3; x++) {
                addSlot(new Slot(bin, x + y * 3, 30 + x * 18, 17 + y * 18) {
                    @Override
                    public boolean mayPlace(ItemStack stack) {
                        return CompostAPI.isCompostable(stack);
                    }
                });
            }
        }
        addSlot(new Slot(bin, CompostBinBlockEntity.OUTPUT, 123, 34) {
            @Override public boolean mayPlace(ItemStack stack) { return false; }
        });
        addPlayerSlots(playerInv, 8, 84);
        addDataSlots(data);
    }

    public int getDecomposeScaled(int scale) {
        int time = data.get(0);
        int max = data.get(1);
        int count = data.get(2);
        if (max == 0) max = 200;
        return (8 - count) * scale / 9 + (time * scale / (max * 9));
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index < 10) {
                if (!moveItemStackTo(stack, 10, 46, true)) return ItemStack.EMPTY;
            } else if (!moveItemStackTo(stack, 0, 9, false)) {
                return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) slot.set(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return bin.stillValid(player);
    }
}
