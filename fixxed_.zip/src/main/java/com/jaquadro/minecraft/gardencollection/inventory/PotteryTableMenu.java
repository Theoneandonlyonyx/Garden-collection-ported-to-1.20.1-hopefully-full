package com.jaquadro.minecraft.gardencollection.inventory;

import com.jaquadro.minecraft.gardencollection.block.entity.PotteryTableBlockEntity;
import com.jaquadro.minecraft.gardencollection.item.PotteryPatternItem;
import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import com.jaquadro.minecraft.gardencollection.registry.ModMenus;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;

public class PotteryTableMenu extends BaseMenu {
    private final PotteryTableBlockEntity table;
    private final ResultContainer result = new ResultContainer();

    public PotteryTableMenu(int id, Inventory playerInv, FriendlyByteBuf buf) {
        this(id, playerInv, (PotteryTableBlockEntity) playerInv.player.level().getBlockEntity(buf.readBlockPos()));
    }

    public PotteryTableMenu(int id, Inventory playerInv, PotteryTableBlockEntity table) {
        super(ModMenus.POTTERY_TABLE.get(), id);
        this.table = table;
        addSlot(new Slot(table, 0, 50, 44) {
            @Override public boolean mayPlace(ItemStack stack) { return PotteryPatternItem.isPattern(stack) || stack.getItem() instanceof DyeItem; }
            @Override public void setChanged() { super.setChanged(); refresh(); }
        });
        addSlot(new Slot(table, 1, 50, 80) {
            @Override public void setChanged() { super.setChanged(); refresh(); }
        });
        addSlot(new Slot(result, 0, 110, 62) {
            @Override public boolean mayPlace(ItemStack stack) { return false; }
            @Override
            public void onTake(Player player, ItemStack stack) {
                if (table.getItem(0).getItem() instanceof DyeItem) table.removeItem(0, 1);
                table.removeItem(1, 1);
                refresh();
                super.onTake(player, stack);
            }
        });
        for (int i = 0; i < 6; i++) addSlot(new Slot(table, 2 + i, 26, 18 + i * 18));
        for (int i = 0; i < 6; i++) addSlot(new Slot(table, 8 + i, 138, 18 + i * 18));
        addPlayerSlots(playerInv, 10, 140);
        refresh();
    }

    private void refresh() {
        ItemStack pattern = table.getItem(0);
        ItemStack target = table.getItem(1);
        result.setItem(0, craft(pattern, target));
    }

    private ItemStack craft(ItemStack pattern, ItemStack target) {
        if (target.isEmpty()) return ItemStack.EMPTY;
        boolean clay = target.is(Items.CLAY_BALL) || target.is(Items.CLAY);
        if (clay) {
            int id = PotteryPatternItem.patternOf(pattern);
            Block block = id <= 0 ? ModBlocks.RAW_LARGE_POT.get() : ModBlocks.ALL.get("raw_large_pot_" + id).get();
            return new ItemStack(block);
        }
        if (pattern.getItem() instanceof DyeItem dye && target.is(ModBlocks.LARGE_POT.get().asItem())) {
            String name = "large_pot_" + dye.getDyeColor().getName();
            var ro = ModBlocks.ALL.get(name);
            if (ro != null) return new ItemStack(ro.get());
        }
        int id = PotteryPatternItem.patternOf(pattern);
        if (id > 0 && (target.is(ModBlocks.RAW_LARGE_POT.get().asItem()) || target.getItem().toString().contains("raw_large_pot"))) {
            var ro = ModBlocks.ALL.get("raw_large_pot_" + id);
            if (ro != null) return new ItemStack(ro.get());
        }
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack resultStack = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            resultStack = stack.copy();
            int playerStart = 15;
            if (index == 2) {
                if (!moveItemStackTo(stack, playerStart, slots.size(), true)) return ItemStack.EMPTY;
                slot.onQuickCraft(stack, resultStack);
            } else if (index >= playerStart) {
                if (!moveItemStackTo(stack, 0, 2, false) && !moveItemStackTo(stack, 3, 15, false)) return ItemStack.EMPTY;
            } else if (!moveItemStackTo(stack, playerStart, slots.size(), false)) {
                return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) slot.set(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return resultStack;
    }

    @Override
    public boolean stillValid(Player player) { return table.stillValid(player); }
}
