package com.jaquadro.minecraft.gardencollection.item;

import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class MossPasteItem extends Item {
    public MossPasteItem() {
        super(new Properties().durability(64));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        var level = context.getLevel();
        var pos = context.getClickedPos();
        BlockState state = level.getBlockState(pos);
        BlockState next = convert(state);
        if (next == null) return InteractionResult.PASS;
        if (!level.isClientSide) {
            level.setBlock(pos, next, 3);
            context.getItemInHand().hurtAndBreak(1, context.getPlayer(), p -> p.broadcastBreakEvent(context.getHand()));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    private static BlockState convert(BlockState state) {
        Block block = state.getBlock();
        if (block == Blocks.STONE_BRICKS) return Blocks.MOSSY_STONE_BRICKS.defaultBlockState();
        if (block == Blocks.MOSSY_STONE_BRICKS) return ModBlocks.ALL.get("moss_brick_mossy_2").get().defaultBlockState();
        if (block == ModBlocks.ALL.get("moss_brick_mossy_2").get()) return ModBlocks.ALL.get("moss_brick_mossy_3").get().defaultBlockState();
        if (block == ModBlocks.ALL.get("moss_brick_mossy_3").get()) return ModBlocks.ALL.get("moss_brick_mossy_4").get().defaultBlockState();
        if (block == Blocks.CRACKED_STONE_BRICKS) return ModBlocks.ALL.get("moss_brick_cracked_mossy_1").get().defaultBlockState();
        if (block == ModBlocks.ALL.get("moss_brick_cracked_mossy_1").get()) return ModBlocks.ALL.get("moss_brick_cracked_mossy_2").get().defaultBlockState();
        if (block == ModBlocks.ALL.get("moss_brick_cracked_mossy_2").get()) return ModBlocks.ALL.get("moss_brick_cracked_mossy_3").get().defaultBlockState();
        if (block == ModBlocks.ALL.get("moss_brick_cracked_mossy_3").get()) return ModBlocks.ALL.get("moss_brick_cracked_mossy_4").get().defaultBlockState();
        if (block == Blocks.COBBLESTONE) return Blocks.MOSSY_COBBLESTONE.defaultBlockState();
        return null;
    }
}
