package com.jaquadro.minecraft.gardencollection.item;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.LayeredCauldronBlock;
import net.minecraft.world.level.block.Blocks;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class PotteryPatternItem extends Item {
    private final boolean dirty;

    public PotteryPatternItem(boolean dirty) {
        super(new Properties().stacksTo(1));
        this.dirty = dirty;
    }

    public static ItemStack stack(Item item, int pattern) {
        ItemStack stack = new ItemStack(item);
        stack.getOrCreateTag().putInt("Pattern", pattern);
        return stack;
    }

    public static int patternOf(ItemStack stack) {
        if (!(stack.getItem() instanceof PotteryPatternItem item) || item.dirty) return 0;
        CompoundTag tag = stack.getTag();
        if (tag == null) return 0;
        return Math.max(0, Math.min(13, tag.getInt("Pattern")));
    }

    public static boolean isPattern(ItemStack stack) {
        return stack.getItem() instanceof PotteryPatternItem item && !item.dirty && patternOf(stack) > 0;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        int pattern = stack.hasTag() ? stack.getTag().getInt("Pattern") : 0;
        if (pattern > 0) {
            tooltip.add(Component.translatable("pattern.gardencollection." + pattern).withStyle(ChatFormatting.GRAY));
        }
        if (dirty) {
            tooltip.add(Component.translatable("item.gardencollection.pottery_pattern_dirty.desc").withStyle(ChatFormatting.DARK_GRAY));
        }
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (!dirty) return InteractionResult.PASS;
        Level level = context.getLevel();
        var state = level.getBlockState(context.getClickedPos());
        if (!state.is(Blocks.WATER_CAULDRON)) return InteractionResult.PASS;
        int fill = state.getValue(LayeredCauldronBlock.LEVEL);
        if (fill <= 0) return InteractionResult.PASS;
        if (!level.isClientSide) {
            ItemStack clean = stack(com.jaquadro.minecraft.gardencollection.registry.ModItems.POTTERY_PATTERN.get(), context.getItemInHand().getOrCreateTag().getInt("Pattern"));
            context.getItemInHand().shrink(1);
            if (!context.getPlayer().addItem(clean)) {
                context.getPlayer().drop(clean, false);
            }
            LayeredCauldronBlock.lowerFillLevel(state, level, context.getClickedPos());
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public String getDescriptionId(ItemStack stack) {
        return dirty ? "item." + GardenCollection.MODID + ".pottery_pattern_dirty" : "item." + GardenCollection.MODID + ".pottery_pattern";
    }
}
