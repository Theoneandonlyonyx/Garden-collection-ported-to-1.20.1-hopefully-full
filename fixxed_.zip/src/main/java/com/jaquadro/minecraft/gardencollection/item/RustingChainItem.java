package com.jaquadro.minecraft.gardencollection.item;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LayeredCauldronBlock;
import net.minecraftforge.registries.ForgeRegistries;

public class RustingChainItem extends BlockItem {
    private final String rustedId;

    public RustingChainItem(net.minecraft.world.level.block.Block block, Properties properties, String rustedId) {
        super(block, properties);
        this.rustedId = rustedId;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        var level = context.getLevel();
        var state = level.getBlockState(context.getClickedPos());
        if (state.is(Blocks.WATER_CAULDRON) && state.getValue(LayeredCauldronBlock.LEVEL) > 0) {
            if (!level.isClientSide) {
                var rusted = ForgeRegistries.ITEMS.getValue(new ResourceLocation(GardenCollection.MODID, rustedId));
                if (rusted != null) {
                    ItemStack out = new ItemStack(rusted);
                    context.getItemInHand().shrink(1);
                    if (context.getPlayer() == null || !context.getPlayer().addItem(out)) {
                        net.minecraft.world.Containers.dropItemStack(level, context.getClickedPos().getX(), context.getClickedPos().getY() + 1, context.getClickedPos().getZ(), out);
                    }
                    LayeredCauldronBlock.lowerFillLevel(state, level, context.getClickedPos());
                    level.playSound(null, context.getClickedPos(), SoundEvents.GENERIC_SPLASH, SoundSource.BLOCKS, 0.4F, 1.0F);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return super.useOn(context);
    }
}
