package com.jaquadro.minecraft.gardencollection.item;

import com.jaquadro.minecraft.gardencollection.registry.ModItems;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;

public class SoilTestKitItem extends Item {
    public SoilTestKitItem() {
        super(new Properties().stacksTo(16));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        var player = context.getPlayer();
        if (player == null) return InteractionResult.PASS;
        var level = context.getLevel();
        var biome = level.getBiome(context.getClickedPos()).value();
        int temperature = (int) (Mth.clamp(biome.getBaseTemperature(), 0.0F, 1.0F) * 255) & 255;
        int rainfall = (int) (Mth.clamp(biome.getModifiedClimateSettings().downfall(), 0.0F, 1.0F) * 255) & 255;
        ItemStack used = new ItemStack(ModItems.USED_SOIL_KIT.get());
        used.getOrCreateTag().putInt("Reading", (rainfall << 8) | temperature);
        level.playSound(null, context.getClickedPos(), SoundEvents.GRASS_STEP, SoundSource.PLAYERS, 1.0F, 1.0F);
        if (!level.isClientSide) {
            ItemStack held = context.getItemInHand();
            if (held.getCount() == 1) {
                player.setItemInHand(context.getHand(), used);
            } else {
                held.shrink(1);
                if (!player.addItem(used)) player.drop(used, false);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
