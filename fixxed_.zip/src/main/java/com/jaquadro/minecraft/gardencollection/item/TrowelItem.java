package com.jaquadro.minecraft.gardencollection.item;

import com.jaquadro.minecraft.gardencollection.block.GardenProxyBlock;
import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.network.NetworkHooks;

public class TrowelItem extends Item {
    public TrowelItem() {
        super(new Properties().stacksTo(1).durability(250));
    }

    private static boolean isDirtType(BlockState state) {
        return state.is(BlockTags.DIRT) || state.is(Blocks.FARMLAND) || state.is(Blocks.DIRT_PATH)
                || state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.PODZOL) || state.is(Blocks.MYCELIUM)
                || state.is(Blocks.COARSE_DIRT) || state.is(Blocks.ROOTED_DIRT) || state.is(Blocks.MUD)
                || state.is(ModBlocks.GARDEN_SOIL.get()) || state.is(ModBlocks.GARDEN_FARMLAND.get());
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos clicked = context.getClickedPos();
        BlockPos host = null;

        if (level.getBlockEntity(clicked) instanceof GardenBlockEntity) {
            host = clicked; // pot, window box, garden soil, hosted proxy
        } else {
            BlockState state = level.getBlockState(clicked);
            BlockPos above = clicked.above();
            BlockState aboveState = level.getBlockState(above);
            if (aboveState.getBlock() instanceof GardenProxyBlock && aboveState.getValue(GardenProxyBlock.HOSTED)) {
                host = above;
            } else if (isDirtType(state) && (aboveState.isAir() || aboveState.canBeReplaced())) {
                if (!level.isClientSide) {
                    level.setBlock(above, ModBlocks.GARDEN_PROXY.get().defaultBlockState().setValue(GardenProxyBlock.HOSTED, true), 3);
                    if (context.getPlayer() != null) {
                        context.getItemInHand().hurtAndBreak(1, context.getPlayer(), p -> p.broadcastBreakEvent(context.getHand()));
                    }
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        if (host == null) {
            return InteractionResult.PASS;
        }
        if (!level.isClientSide && context.getPlayer() instanceof ServerPlayer serverPlayer && level.getBlockEntity(host) instanceof GardenBlockEntity garden) {
            NetworkHooks.openScreen(serverPlayer, new net.minecraft.world.MenuProvider() {
                @Override
                public net.minecraft.network.chat.Component getDisplayName() {
                    return net.minecraft.network.chat.Component.translatable("container.gardencollection.garden");
                }

                @Override
                public net.minecraft.world.inventory.AbstractContainerMenu createMenu(int id, net.minecraft.world.entity.player.Inventory inv, net.minecraft.world.entity.player.Player player) {
                    return new com.jaquadro.minecraft.gardencollection.inventory.GardenMenu(id, inv, garden);
                }
            }, host);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
