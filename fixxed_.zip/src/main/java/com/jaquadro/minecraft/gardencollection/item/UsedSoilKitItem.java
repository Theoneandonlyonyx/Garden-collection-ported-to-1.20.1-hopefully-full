package com.jaquadro.minecraft.gardencollection.item;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class UsedSoilKitItem extends Item {
    public UsedSoilKitItem() {
        super(new Properties().stacksTo(1));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        CompoundTag tag = stack.getTag();
        int packed = tag == null ? 0 : tag.getInt("Reading");
        int temperature = packed & 255;
        int rainfall = (packed >> 8) & 255;
        tooltip.add(Component.translatable("item.gardencollection.soil_test_kit.temperature", percent(temperature)).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.gardencollection.soil_test_kit.rainfall", percent(rainfall)).withStyle(ChatFormatting.GRAY));
    }

    private static int percent(int value) {
        return (int) Math.round(value * 100.0 / 255.0);
    }
}
