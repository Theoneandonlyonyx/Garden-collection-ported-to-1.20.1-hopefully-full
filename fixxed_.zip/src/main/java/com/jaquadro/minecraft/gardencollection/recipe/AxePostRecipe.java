package com.jaquadro.minecraft.gardencollection.recipe;

import com.google.gson.JsonObject;
import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import com.jaquadro.minecraft.gardencollection.registry.ModRecipeSerializers;
import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

import java.util.HashMap;
import java.util.Map;

public class AxePostRecipe implements CraftingRecipe {
    private final ResourceLocation id;
    private static final Map<Item, String> LOGS = new HashMap<>();

    static {
        put(Items.OAK_LOG, "oak");
        put(Items.OAK_WOOD, "oak");
        put(Items.STRIPPED_OAK_LOG, "oak");
        put(Items.STRIPPED_OAK_WOOD, "oak");
        put(Items.SPRUCE_LOG, "spruce");
        put(Items.SPRUCE_WOOD, "spruce");
        put(Items.STRIPPED_SPRUCE_LOG, "spruce");
        put(Items.STRIPPED_SPRUCE_WOOD, "spruce");
        put(Items.BIRCH_LOG, "birch");
        put(Items.BIRCH_WOOD, "birch");
        put(Items.STRIPPED_BIRCH_LOG, "birch");
        put(Items.STRIPPED_BIRCH_WOOD, "birch");
        put(Items.JUNGLE_LOG, "jungle");
        put(Items.JUNGLE_WOOD, "jungle");
        put(Items.STRIPPED_JUNGLE_LOG, "jungle");
        put(Items.STRIPPED_JUNGLE_WOOD, "jungle");
        put(Items.ACACIA_LOG, "acacia");
        put(Items.ACACIA_WOOD, "acacia");
        put(Items.STRIPPED_ACACIA_LOG, "acacia");
        put(Items.STRIPPED_ACACIA_WOOD, "acacia");
        put(Items.DARK_OAK_LOG, "dark_oak");
        put(Items.DARK_OAK_WOOD, "dark_oak");
        put(Items.STRIPPED_DARK_OAK_LOG, "dark_oak");
        put(Items.STRIPPED_DARK_OAK_WOOD, "dark_oak");
    }

    private static void put(Item item, String wood) {
        LOGS.put(item, wood);
    }

    public AxePostRecipe(ResourceLocation id) {
        this.id = id;
    }

    @Override
    public CraftingBookCategory category() {
        return CraftingBookCategory.MISC;
    }

    private ItemStack findLog(CraftingContainer inv) {
        int width = inv.getWidth();
        int height = inv.getHeight();
        ItemStack found = ItemStack.EMPTY;
        for (int y = 0; y < height - 1; y++) {
            for (int x = 0; x < width; x++) {
                ItemStack top = inv.getItem(x + y * width);
                ItemStack below = inv.getItem(x + (y + 1) * width);
                if (top.is(ItemTags.AXES) && LOGS.containsKey(below.getItem())) {
                    if (!found.isEmpty()) return ItemStack.EMPTY;
                    found = below;
                }
            }
        }
        if (found.isEmpty()) return ItemStack.EMPTY;
        int extras = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty()) continue;
            if (stack.is(ItemTags.AXES) || LOGS.containsKey(stack.getItem())) extras++;
            else return ItemStack.EMPTY;
        }
        return extras == 2 ? found : ItemStack.EMPTY;
    }

    @Override
    public boolean matches(CraftingContainer inv, Level level) {
        return !findLog(inv).isEmpty();
    }

    @Override
    public ItemStack assemble(CraftingContainer inv, RegistryAccess access) {
        ItemStack log = findLog(inv);
        if (log.isEmpty()) return ItemStack.EMPTY;
        String wood = LOGS.get(log.getItem());
        Block block = ModBlocks.ALL.get("thin_log_" + wood).get();
        return new ItemStack(block, 4);
    }

    @Override
    public NonNullList<ItemStack> getRemainingItems(CraftingContainer inv) {
        NonNullList<ItemStack> remaining = NonNullList.withSize(inv.getContainerSize(), ItemStack.EMPTY);
        for (int i = 0; i < remaining.size(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.is(ItemTags.AXES)) {
                ItemStack copy = stack.copy();
                copy.setCount(1);
                int damage = copy.getDamageValue() + 1;
                if (damage >= copy.getMaxDamage()) remaining.set(i, ItemStack.EMPTY);
                else {
                    copy.setDamageValue(damage);
                    remaining.set(i, copy);
                }
            }
        }
        return remaining;
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return width >= 1 && height >= 2;
    }

    @Override
    public ItemStack getResultItem(RegistryAccess access) {
        return new ItemStack(ModBlocks.ALL.get("thin_log_oak").get(), 4);
    }

    @Override
    public ResourceLocation getId() {
        return id;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return ModRecipeSerializers.AXE_POST.get();
    }

    public static class Serializer implements RecipeSerializer<AxePostRecipe> {
        @Override
        public AxePostRecipe fromJson(ResourceLocation id, JsonObject json) {
            return new AxePostRecipe(id);
        }

        @Override
        public AxePostRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buf) {
            return new AxePostRecipe(id);
        }

        @Override
        public void toNetwork(FriendlyByteBuf buf, AxePostRecipe recipe) {
        }
    }
}
