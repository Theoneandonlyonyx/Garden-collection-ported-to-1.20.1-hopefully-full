package com.jaquadro.minecraft.gardencollection.registry;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import com.jaquadro.minecraft.gardencollection.block.entity.BloomeryBlockEntity;
import com.jaquadro.minecraft.gardencollection.block.entity.CompostBinBlockEntity;
import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import com.jaquadro.minecraft.gardencollection.block.entity.LanternBlockEntity;
import com.jaquadro.minecraft.gardencollection.block.entity.PotteryTableBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, GardenCollection.MODID);

    public static final RegistryObject<BlockEntityType<GardenBlockEntity>> GARDEN = BLOCK_ENTITIES.register("garden",
            () -> BlockEntityType.Builder.of(GardenBlockEntity::new, ModBlocks.gardenBlocks()).build(null));
    public static final RegistryObject<BlockEntityType<CompostBinBlockEntity>> COMPOST_BIN = BLOCK_ENTITIES.register("compost_bin",
            () -> BlockEntityType.Builder.of(CompostBinBlockEntity::new, ModBlocks.COMPOST_BIN.get()).build(null));
    public static final RegistryObject<BlockEntityType<BloomeryBlockEntity>> BLOOMERY = BLOCK_ENTITIES.register("bloomery_furnace",
            () -> BlockEntityType.Builder.of(BloomeryBlockEntity::new, ModBlocks.BLOOMERY_FURNACE.get()).build(null));
    public static final RegistryObject<BlockEntityType<PotteryTableBlockEntity>> POTTERY_TABLE = BLOCK_ENTITIES.register("pottery_table",
            () -> BlockEntityType.Builder.of(PotteryTableBlockEntity::new, ModBlocks.POTTERY_TABLE.get()).build(null));
    public static final RegistryObject<BlockEntityType<LanternBlockEntity>> LANTERN = BLOCK_ENTITIES.register("lantern",
            () -> BlockEntityType.Builder.of(LanternBlockEntity::new, ModBlocks.LANTERN.get()).build(null));

    private ModBlockEntities() {}
}
