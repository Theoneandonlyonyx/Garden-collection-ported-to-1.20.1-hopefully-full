package com.jaquadro.minecraft.gardencollection.registry;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import com.jaquadro.minecraft.gardencollection.item.PotteryPatternItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GardenCollection.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.gardencollection"))
            .icon(() -> new ItemStack(ModBlocks.LARGE_POT.get()))
            .displayItems((params, output) -> {
                for (var entry : ModItems.ALL.entrySet()) {
                    String name = entry.getKey();
                    if (name.equals("pottery_pattern_dirty")) {
                        continue;
                    }
                    Item item = entry.getValue().get();
                    if (name.equals("pottery_pattern")) {
                        for (int i = 1; i <= 13; i++) {
                            output.accept(PotteryPatternItem.stack(item, i));
                        }
                        continue;
                    }
                    // raw patterned pots are made at the pottery table only
                    if (name.startsWith("raw_large_pot_")) {
                        continue;
                    }
                    output.accept(item);
                }
            })
            .build());

    private ModCreativeTabs() {}
}
