package com.jaquadro.minecraft.gardencollection.registry;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import com.jaquadro.minecraft.gardencollection.item.*;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, GardenCollection.MODID);
    /** Every item of the mod by registry name (insertion ordered). Block items come last. */
    public static final Map<String, RegistryObject<Item>> ALL = new LinkedHashMap<>();

    /** Blocks that get no block item of their own. */
    private static final Set<String> NO_BLOCK_ITEM = Set.of("small_fire", "garden_farmland", "candelilla", "garden_proxy");

    private static RegistryObject<Item> reg(String name, Supplier<? extends Item> supplier) {
        RegistryObject<Item> object = ITEMS.register(name, () -> (Item) supplier.get());
        ALL.put(name, object);
        return object;
    }

    private static Item.Properties props() {
        return new Item.Properties();
    }

    public static final RegistryObject<Item> TROWEL = reg("trowel", TrowelItem::new);
    public static final RegistryObject<Item> SOIL_TEST_KIT = reg("soil_test_kit", SoilTestKitItem::new);
    public static final RegistryObject<Item> USED_SOIL_KIT = reg("used_soil_kit", UsedSoilKitItem::new);
    public static final RegistryObject<Item> COMPOST = reg("compost", () -> new BoneMealItem(props()));
    public static final RegistryObject<Item> WAX = reg("wax", () -> new Item(props()));
    public static final RegistryObject<Item> CANDLE = reg("candle", () -> new Item(props()));
    public static final RegistryObject<Item> MOSS_PASTE = reg("moss_paste", MossPasteItem::new);
    public static final RegistryObject<Item> WROUGHT_IRON_INGOT = reg("wrought_iron_ingot", () -> new Item(props()));
    public static final RegistryObject<Item> WROUGHT_IRON_NUGGET = reg("wrought_iron_nugget", () -> new Item(props()));
    public static final RegistryObject<Item> CHAIN_LINK_IRON = reg("chain_link_iron", () -> new Item(props()));
    public static final RegistryObject<Item> CHAIN_LINK_GOLD = reg("chain_link_gold", () -> new Item(props()));
    public static final RegistryObject<Item> CHAIN_LINK_WROUGHT_IRON = reg("chain_link_wrought_iron", () -> new Item(props()));
    public static final RegistryObject<Item> POTTERY_PATTERN = reg("pottery_pattern", () -> new PotteryPatternItem(false));
    public static final RegistryObject<Item> POTTERY_PATTERN_DIRTY = reg("pottery_pattern_dirty", () -> new PotteryPatternItem(true));
    public static final RegistryObject<Item> CANDELILLA = reg("candelilla", () -> new Item(props()));
    public static final RegistryObject<Item> CANDELILLA_SEEDS = reg("candelilla_seeds", () -> new ItemNameBlockItem(ModBlocks.CANDELILLA.get(), props()));

    static {
        // one block item for every registered block
        for (Map.Entry<String, RegistryObject<Block>> entry : ModBlocks.ALL.entrySet()) {
            final String name = entry.getKey();
            if (NO_BLOCK_ITEM.contains(name)) {
                continue;
            }
            final RegistryObject<Block> block = entry.getValue();
            reg(name, () -> blockItem(name, block.get()));
        }
    }

    private static Item blockItem(String name, Block block) {
        if (name.equals("charcoal_block")) {
            return new FuelBlockItem(block, props(), 16000);
        }
        if (name.equals("chain_light_iron") || name.equals("chain_light_wrought_iron")) {
            return new RustingChainItem(block, props(), "chain_light_rust");
        }
        if (name.equals("chain_heavy_iron") || name.equals("chain_heavy_wrought_iron")) {
            return new RustingChainItem(block, props(), "chain_heavy_rust");
        }
        return new BlockItem(block, props());
    }

    private ModItems() {}
}
