package com.jaquadro.minecraft.gardencollection.registry;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import com.jaquadro.minecraft.gardencollection.inventory.BloomeryMenu;
import com.jaquadro.minecraft.gardencollection.inventory.CompostBinMenu;
import com.jaquadro.minecraft.gardencollection.inventory.GardenMenu;
import com.jaquadro.minecraft.gardencollection.inventory.PotteryTableMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, GardenCollection.MODID);

    public static final RegistryObject<MenuType<GardenMenu>> GARDEN = MENUS.register("garden",
            () -> IForgeMenuType.create((id, inv, buf) -> new GardenMenu(id, inv, buf)));
    public static final RegistryObject<MenuType<CompostBinMenu>> COMPOST_BIN = MENUS.register("compost_bin",
            () -> IForgeMenuType.create((id, inv, buf) -> new CompostBinMenu(id, inv, buf)));
    public static final RegistryObject<MenuType<BloomeryMenu>> BLOOMERY = MENUS.register("bloomery_furnace",
            () -> IForgeMenuType.create((id, inv, buf) -> new BloomeryMenu(id, inv, buf)));
    public static final RegistryObject<MenuType<PotteryTableMenu>> POTTERY_TABLE = MENUS.register("pottery_table",
            () -> IForgeMenuType.create((id, inv, buf) -> new PotteryTableMenu(id, inv, buf)));

    private ModMenus() {}
}
