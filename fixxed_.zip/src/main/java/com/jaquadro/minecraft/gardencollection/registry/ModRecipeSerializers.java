package com.jaquadro.minecraft.gardencollection.registry;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import com.jaquadro.minecraft.gardencollection.recipe.AxePostRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRecipeSerializers {
    public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS = DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, GardenCollection.MODID);

    public static final RegistryObject<RecipeSerializer<AxePostRecipe>> AXE_POST = SERIALIZERS.register("axe_post", AxePostRecipe.Serializer::new);

    private ModRecipeSerializers() {}
}
