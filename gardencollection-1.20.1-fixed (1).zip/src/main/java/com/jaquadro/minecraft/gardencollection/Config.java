package com.jaquadro.minecraft.gardencollection;

// Placeholder for Config.java