package com.jaquadro.minecraft.gardencollection;

// Placeholder for GardenCollection.java