package com.jaquadro.minecraft.gardencollection.api;

// Placeholder for CompostAPI.java