package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for BloomeryFurnaceBlock.java