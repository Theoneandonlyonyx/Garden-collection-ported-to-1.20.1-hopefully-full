package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for CandelabraBlock.java