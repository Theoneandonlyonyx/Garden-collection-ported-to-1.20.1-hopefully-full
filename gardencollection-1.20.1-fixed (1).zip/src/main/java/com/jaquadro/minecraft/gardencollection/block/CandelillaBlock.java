package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for CandelillaBlock.java