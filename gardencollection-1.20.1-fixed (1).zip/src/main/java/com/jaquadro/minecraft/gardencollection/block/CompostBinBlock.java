package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for CompostBinBlock.java