package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for GardenFarmlandBlock.java