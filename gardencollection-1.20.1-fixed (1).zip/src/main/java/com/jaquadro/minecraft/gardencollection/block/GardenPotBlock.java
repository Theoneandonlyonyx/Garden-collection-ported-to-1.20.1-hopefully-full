package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for GardenPotBlock.java