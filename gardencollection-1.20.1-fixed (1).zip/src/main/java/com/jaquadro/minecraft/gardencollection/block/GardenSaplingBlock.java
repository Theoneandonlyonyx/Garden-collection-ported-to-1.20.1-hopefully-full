package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for GardenSaplingBlock.java