package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for GardenSoilBlock.java