package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for HoopBlock.java