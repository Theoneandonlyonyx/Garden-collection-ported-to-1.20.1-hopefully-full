package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for IvyBlock.java