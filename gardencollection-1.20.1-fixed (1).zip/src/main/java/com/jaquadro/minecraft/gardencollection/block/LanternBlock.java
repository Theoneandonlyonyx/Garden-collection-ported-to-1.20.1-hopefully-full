package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for LanternBlock.java