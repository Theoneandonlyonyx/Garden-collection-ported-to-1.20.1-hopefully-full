package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for PotShape.java