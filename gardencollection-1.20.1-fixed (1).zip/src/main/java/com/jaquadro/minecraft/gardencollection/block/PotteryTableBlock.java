package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for PotteryTableBlock.java