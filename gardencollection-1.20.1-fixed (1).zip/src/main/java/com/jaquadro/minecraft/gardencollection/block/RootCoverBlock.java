package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for RootCoverBlock.java