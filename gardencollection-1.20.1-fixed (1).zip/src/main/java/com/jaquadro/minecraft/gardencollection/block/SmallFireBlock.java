package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for SmallFireBlock.java