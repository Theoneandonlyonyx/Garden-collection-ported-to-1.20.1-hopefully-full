package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for StrangePlantBlock.java