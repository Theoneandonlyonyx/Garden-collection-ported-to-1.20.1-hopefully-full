package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for ThinLogBlock.java