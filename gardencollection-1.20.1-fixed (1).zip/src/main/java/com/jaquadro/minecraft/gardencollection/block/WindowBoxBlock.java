package com.jaquadro.minecraft.gardencollection.block;

// Placeholder for WindowBoxBlock.java