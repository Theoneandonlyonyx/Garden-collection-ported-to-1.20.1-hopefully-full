package com.jaquadro.minecraft.gardencollection.block.entity;

// Placeholder for BloomeryBlockEntity.java