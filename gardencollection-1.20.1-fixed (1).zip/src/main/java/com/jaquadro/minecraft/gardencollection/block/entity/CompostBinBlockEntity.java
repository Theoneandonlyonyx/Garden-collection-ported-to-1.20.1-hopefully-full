package com.jaquadro.minecraft.gardencollection.block.entity;

// Placeholder for CompostBinBlockEntity.java