package com.jaquadro.minecraft.gardencollection.block.entity;

// Placeholder for PotteryTableBlockEntity.java