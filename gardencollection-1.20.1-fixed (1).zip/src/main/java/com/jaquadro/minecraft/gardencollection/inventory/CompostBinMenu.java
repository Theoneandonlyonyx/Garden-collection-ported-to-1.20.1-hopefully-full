package com.jaquadro.minecraft.gardencollection.inventory;

// Placeholder for CompostBinMenu.java