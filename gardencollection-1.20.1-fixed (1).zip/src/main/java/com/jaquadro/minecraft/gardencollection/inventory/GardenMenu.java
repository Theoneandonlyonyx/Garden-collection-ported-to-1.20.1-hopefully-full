package com.jaquadro.minecraft.gardencollection.inventory;

// Placeholder for GardenMenu.java