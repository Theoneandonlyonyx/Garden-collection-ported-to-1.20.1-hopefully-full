package com.jaquadro.minecraft.gardencollection.inventory;

// Placeholder for PotteryTableMenu.java