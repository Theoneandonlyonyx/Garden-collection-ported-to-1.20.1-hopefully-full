package com.jaquadro.minecraft.gardencollection.item;

// Placeholder for FuelBlockItem.java