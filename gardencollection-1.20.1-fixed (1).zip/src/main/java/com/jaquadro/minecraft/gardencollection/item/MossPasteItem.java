package com.jaquadro.minecraft.gardencollection.item;

// Placeholder for MossPasteItem.java