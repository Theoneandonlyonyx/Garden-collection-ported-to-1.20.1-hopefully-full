package com.jaquadro.minecraft.gardencollection.item;

// Placeholder for PotteryPatternItem.java