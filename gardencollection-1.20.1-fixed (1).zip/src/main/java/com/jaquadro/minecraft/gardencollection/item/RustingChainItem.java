package com.jaquadro.minecraft.gardencollection.item;

// Placeholder for RustingChainItem.java