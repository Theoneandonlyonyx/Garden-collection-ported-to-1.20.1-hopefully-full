package com.jaquadro.minecraft.gardencollection.mixin;

// Placeholder for CropBlockMixin.java