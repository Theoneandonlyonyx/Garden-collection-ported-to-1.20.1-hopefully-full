package com.jaquadro.minecraft.gardencollection.recipe;

// Placeholder for AxePostRecipe.java