package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import org.jetbrains.annotations.Nullable;

public class GardenSoilBlock extends Block {
    public GardenSoilBlock() {
        super(BlockBehaviour.Properties.of().mapColor(MapColor.DIRT).strength(0.5F).sound(net.minecraft.world.level.block.SoundType.GRAVEL));
    }

    /** Hoes turn garden soil into tilled garden soil (replaces the 1.7.10 hoe event). */
    @Nullable
    @Override
    public BlockState getToolModifiedState(BlockState state, UseOnContext context, ToolAction toolAction, boolean simulate) {
        if (toolAction == ToolActions.HOE_TILL && context.getLevel().getBlockState(context.getClickedPos().above()).isAir()) {
            return ModBlocks.GARDEN_FARMLAND.get().defaultBlockState();
        }
        return super.getToolModifiedState(state, context, toolAction, simulate);
    }
}
