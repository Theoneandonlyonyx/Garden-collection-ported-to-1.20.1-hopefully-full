package com.jaquadro.minecraft.gardencollection.client.renderer;

import com.jaquadro.minecraft.gardencollection.block.GardenPotBlock;
import com.jaquadro.minecraft.gardencollection.block.WindowBoxBlock;
import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.core.Direction;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

/** Draws the plants that sit in a pot / window box. */
public class GardenBlockEntityRenderer implements BlockEntityRenderer<GardenBlockEntity> {
    private final BlockRenderDispatcher blockRenderer;

    public GardenBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
        this.blockRenderer = context.getBlockRenderDispatcher();
    }

    @Override
    public void render(GardenBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers, int light, int overlay) {
        BlockState potState = be.getBlockState();
        if (!(potState.getBlock() instanceof GardenPotBlock pot)) {
            return;
        }
        int count = be.slotCount();
        double top = pot.potShape().shape.max(Direction.Axis.Y) - 0.05D;
        if (potState.getBlock() instanceof WindowBoxBlock) {
            top = 0.34D;
        }

        for (int i = 0; i < count; i++) {
            ItemStack stack = be.getPlant(i);
            if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem blockItem)) {
                continue;
            }
            double[] p = position(potState, count, i);
            float scale = (float) p[2];
            pose.pushPose();
            pose.translate(p[0] - scale / 2.0D, top, p[1] - scale / 2.0D);
            pose.scale(scale, scale, scale);
            blockRenderer.renderSingleBlock(blockItem.getBlock().defaultBlockState(), pose, buffers, light, overlay);
            pose.popPose();
        }
    }

    /** x, z centre and scale for a slot. */
    private static double[] position(BlockState state, int count, int index) {
        if (state.getBlock() instanceof WindowBoxBlock) {
            Direction facing = state.getValue(WindowBoxBlock.FACING);
            double across = (facing == Direction.NORTH || facing == Direction.WEST) ? 0.19D : 0.81D;
            double along = 0.2D + 0.3D * index;
            return facing.getAxis() == Direction.Axis.X ? new double[]{across, along, 0.5D} : new double[]{along, across, 0.5D};
        }
        if (count == 1) {
            return new double[]{0.5D, 0.5D, 0.75D};
        }
        double[][] cells = {{0.28D, 0.28D}, {0.72D, 0.28D}, {0.28D, 0.72D}, {0.72D, 0.72D}};
        return new double[]{cells[index][0], cells[index][1], 0.42D};
    }
}
