package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Which garden hosts join into one bigger bed (port of BasicConnectionProfile). */
public final class GardenConnection {
    private GardenConnection() {}

    private static Object group(BlockState state) {
        Block block = state.getBlock();
        if (block instanceof LargePotBlock) {
            return block;
        }
        if (block instanceof GardenSoilBlock || block instanceof GardenFarmlandBlock) {
            return "soil";
        }
        if (block instanceof GardenProxyBlock && state.getValue(GardenProxyBlock.HOSTED)) {
            return "soil";
        }
        return null;
    }

    public static boolean connects(GardenBlockEntity a, GardenBlockEntity b) {
        Object ga = group(a.getBlockState());
        return ga != null && ga.equals(group(b.getBlockState()));
    }
}
