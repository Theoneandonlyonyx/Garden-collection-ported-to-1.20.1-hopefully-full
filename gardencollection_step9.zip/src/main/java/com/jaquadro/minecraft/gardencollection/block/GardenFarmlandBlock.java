package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraftforge.common.FarmlandWaterManager;

import java.util.Random;

public class GardenFarmlandBlock extends FarmBlock implements net.minecraft.world.level.block.EntityBlock, GardenHost {
    public GardenFarmlandBlock() {
        super(Properties.copy(net.minecraft.world.level.block.Blocks.FARMLAND).lightLevel(s -> s.getValue(GardenHost.LIGHT)));
        registerDefaultState(defaultBlockState().setValue(GardenHost.LIGHT, 0));
    }

    @org.jetbrains.annotations.Nullable
    @Override
    public net.minecraft.world.level.block.entity.BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity(pos, state);
    }

    @Override
    public int gardenSlots() {
        return 4;
    }

    @Override
    public double plantTop() {
        return 0.9375D;
    }

    @Override
    public net.minecraft.world.InteractionResult use(BlockState state, Level level, BlockPos pos, net.minecraft.world.entity.player.Player player, net.minecraft.world.InteractionHand hand, net.minecraft.world.phys.BlockHitResult hit) {
        if (hand == net.minecraft.world.InteractionHand.MAIN_HAND && GardenHelper.isDecorItem(player.getItemInHand(hand))) {
            return GardenHelper.interact(level, pos, player, hand);
        }
        return net.minecraft.world.InteractionResult.PASS;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock())) {
            GardenHelper.dropAll(level, pos);
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(GardenHost.LIGHT);
    }

    @Override
    public void fallOn(Level level, BlockState state, BlockPos pos, Entity entity, float fallDistance) {
        super.fallOn(level, state, pos, entity, fallDistance);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, net.minecraft.util.RandomSource random) {
        int moisture = state.getValue(MOISTURE);
        if (!isNearWater(level, pos) && !level.isRainingAt(pos.above())) {
            if (moisture > 0) {
                level.setBlock(pos, state.setValue(MOISTURE, moisture - 1), 2);
            } else if (!level.getBlockState(pos.above()).isSolidRender(level, pos.above())) {
                level.setBlockAndUpdate(pos, ModBlocks.GARDEN_SOIL.get().defaultBlockState());
            }
        } else if (moisture < 7) {
            level.setBlock(pos, state.setValue(MOISTURE, 7), 2);
        }
    }

    private static boolean isNearWater(Level level, BlockPos pos) {
        for (BlockPos nearby : BlockPos.betweenClosed(pos.offset(-4, 0, -4), pos.offset(4, 1, 4))) {
            if (level.getBlockState(nearby).getFluidState().is(net.minecraft.tags.FluidTags.WATER) || FarmlandWaterManager.hasBlockWaterTicket(level, nearby)) {
                return true;
            }
        }
        return false;
    }
}
