package com.jaquadro.minecraft.gardencollection.block;

/** Any block that carries a GardenBlockEntity (pots, window boxes, garden soil, tilled soil). */
public interface GardenHost {
    /** Light emitted by whatever is in the host (lanterns, candles, jack o'lanterns, lava...). */
    net.minecraft.world.level.block.state.properties.IntegerProperty LIGHT =
            net.minecraft.world.level.block.state.properties.IntegerProperty.create("light", 0, 15);

    int gardenSlots();

    /** Height (0..1) of the surface plants stand on. */
    double plantTop();

    /** Bit mask of the slots this host has (0 = center, 1 = cover, 2-5 = corners, 6-13 = edges). */
    default int slotMask() {
        return 0x3FFF;
    }

    /** Pots start empty: plants need soil (or liquid) put in by hand. Window boxes / soil don't. */
    default boolean requiresSubstrate() {
        return false;
    }

    /** Height of the pot floor (where decor sits when there is no soil). */
    default double floorY() {
        return plantTop();
    }

    /** Height of the liquid surface. */
    default double fluidY() {
        return plantTop() + 0.01D;
    }
}
