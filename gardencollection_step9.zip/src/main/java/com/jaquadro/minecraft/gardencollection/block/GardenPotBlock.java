package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import com.jaquadro.minecraft.gardencollection.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public class GardenPotBlock extends BaseEntityBlock implements GardenHost, net.minecraft.world.level.block.BonemealableBlock {
    private final int slots;
    private final PotShape potShape;

    public GardenPotBlock(int slots, PotShape potShape) {
        this(slots, potShape, Properties.of().mapColor(MapColor.TERRACOTTA_ORANGE).strength(0.6F).sound(SoundType.STONE).noOcclusion().dynamicShape());
    }

    public GardenPotBlock(int slots, PotShape potShape, BlockBehaviour.Properties properties) {
        super(properties.lightLevel(state -> state.hasProperty(GardenHost.LIGHT) ? state.getValue(GardenHost.LIGHT) : 0));
        registerDefaultState(stateDefinition.any().setValue(GardenHost.LIGHT, 0));
        this.slots = slots;
        this.potShape = potShape;
    }

    @Override
    protected void createBlockStateDefinition(net.minecraft.world.level.block.state.StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(GardenHost.LIGHT);
    }

    public int slots() {
        return slots;
    }

    public PotShape potShape() {
        return potShape;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return potShape.shape;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new GardenBlockEntity(pos, state);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        return GardenHelper.interact(level, pos, player, hand);
    }

    public static boolean isPlant(ItemStack stack) {
        return GardenHelper.accepts(stack);
    }

    @Override
    public int gardenSlots() {
        return Math.min(4, slots);
    }

    @Override
    public double plantTop() {
        return potShape.shape.max(Direction.Axis.Y) - 0.125D;
    }

    @Override
    public double floorY() {
        return 0.125D;
    }

    @Override
    public int slotMask() {
        return 0b11;
    }

    @Override
    public boolean requiresSubstrate() {
        return true;
    }

    @Override
    public boolean isValidBonemealTarget(net.minecraft.world.level.LevelReader level, BlockPos pos, BlockState state, boolean client) {
        return GardenHelper.canBonemeal(level, pos, client);
    }

    @Override
    public boolean isBonemealSuccess(Level level, net.minecraft.util.RandomSource random, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public void performBonemeal(net.minecraft.server.level.ServerLevel level, net.minecraft.util.RandomSource random, BlockPos pos, BlockState state) {
        GardenHelper.applyBonemeal(level, pos, random);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock())) {
            GardenHelper.dropAll(level, pos);
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return null;
    }

    @SuppressWarnings("unused")
    private static Direction unused() {
        return Direction.UP;
    }

    @SuppressWarnings("unused")
    private static EntityBlock marker() {
        return null;
    }

    public static BlockEntityType<GardenBlockEntity> typeOrNull() {
        return ModBlockEntities.GARDEN.get();
    }
}
