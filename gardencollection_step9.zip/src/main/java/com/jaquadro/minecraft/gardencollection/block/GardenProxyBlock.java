package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

/**
 * Invisible plant proxy (port of BlockGardenProxy).
 * hosted=false: sits above a pot / window box / garden soil and forwards clicks, bonemeal and breaking to it.
 * hosted=true : placed by the trowel on top of any dirt-type block and carries the plants itself.
 */
public class GardenProxyBlock extends Block implements BonemealableBlock, EntityBlock, GardenHost {
    public static final BooleanProperty HOSTED = BooleanProperty.create("hosted");
    private static final VoxelShape SELECT = Block.box(2, 0, 2, 14, 14, 14);

    public GardenProxyBlock() {
        super(BlockBehaviour.Properties.of().noCollission().noOcclusion().instabreak().noLootTable()
                .replaceable().lightLevel(s -> s.getValue(GardenHost.LIGHT)).pushReaction(net.minecraft.world.level.material.PushReaction.DESTROY));
        registerDefaultState(stateDefinition.any().setValue(HOSTED, false).setValue(LIGHT, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(HOSTED, LIGHT);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return state.getValue(HOSTED) ? new GardenBlockEntity(pos, state) : null;
    }

    @Override
    public int gardenSlots() {
        return 4;
    }

    @Override
    public double plantTop() {
        return 0.0D;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SELECT;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        return 1.0F;
    }

    @Override
    public boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
        return true;
    }

    private static BlockPos hostPos(BlockState state, BlockPos pos) {
        return state.getValue(HOSTED) ? pos : pos.below();
    }

    private static boolean hasHost(LevelReader level, BlockState state, BlockPos pos) {
        return level.getBlockEntity(hostPos(state, pos)) instanceof GardenBlockEntity;
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (dir == Direction.DOWN) {
            if (!state.getValue(HOSTED) && !(neighbor.getBlock() instanceof GardenHost)) {
                return net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
            }
            if (state.getValue(HOSTED) && neighbor.isAir()) {
                return net.minecraft.world.level.block.Blocks.AIR.defaultBlockState();
            }
        }
        return state;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!hasHost(level, state, pos)) {
            return InteractionResult.PASS;
        }
        return GardenHelper.interact(level, hostPos(state, pos), player, hand);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && level.getBlockEntity(hostPos(state, pos)) instanceof GardenBlockEntity garden) {
            for (int i = garden.slotCount() - 1; i >= 0; i--) {
                ItemStack plant = garden.getPlant(i);
                if (!plant.isEmpty()) {
                    if (!player.getAbilities().instabuild) {
                        Block.popResource(level, pos, plant.copy());
                    }
                    garden.setPlant(i, ItemStack.EMPTY);
                    break;
                }
            }
            if (garden.hasAnyPlant()) {
                level.setBlock(pos, state, 3);
                return;
            }
        }
        super.playerWillDestroy(level, pos, state, player);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (state.getValue(HOSTED) && !state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof GardenBlockEntity garden) {
            for (int i = 0; i < garden.slotCount(); i++) {
                net.minecraft.world.Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), garden.getPlant(i));
            }
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    // ---- bonemeal forwarding
    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state, boolean client) {
        return hasHost(level, state, pos) && GardenHelper.canBonemeal(level, hostPos(state, pos), client);
    }

    @Override
    public boolean isBonemealSuccess(Level level, RandomSource random, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource random, BlockPos pos, BlockState state) {
        GardenHelper.applyBonemeal(level, hostPos(state, pos), random);
    }
}
