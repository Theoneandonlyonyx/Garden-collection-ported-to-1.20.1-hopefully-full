package com.jaquadro.minecraft.gardencollection.block;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.*;

/** The 14-slot layout of the original mod: centre, ground cover, 4 corners and 8 shared edge slots. */
public final class GardenSlots {
    public static final int CENTER = 0, COVER = 1, NW = 2, NE = 3, SW = 4, SE = 5,
            TL = 6, TOP = 7, TR = 8, RIGHT = 9, BR = 10, BOTTOM = 11, BL = 12, LEFT = 13, COUNT = 14;

    /** Plant position inside the block (0..1). Edge slots sit on the block border and are shared. */
    public static final double[] X = {.5, .5, .25, .75, .25, .75, 0, .5, 1, 1, 1, .5, 0, 0};
    public static final double[] Z = {.5, .5, .25, .25, .75, .75, 0, 0, 0, .5, 1, 1, 1, .5};

    /** Cell in the 5x5 GUI grid (the cover slot has its own spot). */
    public static final int[] GUI_X = {2, -1, 1, 3, 1, 3, 0, 2, 4, 4, 4, 2, 0, 0};
    public static final int[] GUI_Y = {2, -1, 1, 1, 3, 3, 0, 0, 0, 2, 4, 4, 4, 2};

    /** Placement order for plants clicked onto a host. */
    public static final int[] ORDER = {CENTER, NE, SW, NW, SE, TOP, RIGHT, BOTTOM, LEFT, TL, TR, BR, BL};

    /** For each edge slot: {dx, dz, slot on that neighbour that is the same spot}. */
    private static final int[][][] SHARE = new int[COUNT][][];

    static {
        SHARE[TOP] = new int[][]{{0, -1, BOTTOM}};
        SHARE[RIGHT] = new int[][]{{1, 0, LEFT}};
        SHARE[BOTTOM] = new int[][]{{0, 1, TOP}};
        SHARE[LEFT] = new int[][]{{-1, 0, RIGHT}};
        SHARE[TL] = new int[][]{{-1, 0, TR}, {0, -1, BL}, {-1, -1, BR}};
        SHARE[TR] = new int[][]{{1, 0, TL}, {0, -1, BR}, {1, -1, BL}};
        SHARE[BR] = new int[][]{{1, 0, BL}, {0, 1, TR}, {1, 1, TL}};
        SHARE[BL] = new int[][]{{-1, 0, BR}, {0, 1, TL}, {-1, 1, TR}};
    }

    private GardenSlots() {}

    public static boolean isEdge(int slot) {
        return slot >= TL;
    }

    public static int[][] shared(int slot) {
        int[][] m = SHARE[slot];
        return m == null ? new int[0][] : m;
    }

    public enum Size { FULL, LARGE, MEDIUM, SMALL }

    private static Block blockOf(ItemStack stack) {
        return stack.getItem() instanceof BlockItem item ? item.getBlock() : null;
    }

    /** Plants that may lie on the ground cover slot. */
    public static boolean isCover(ItemStack stack) {
        Block b = blockOf(stack);
        return b == Blocks.GRASS || b == Blocks.FERN || b == Blocks.MOSS_CARPET;
    }

    public static Size sizeOf(ItemStack stack) {
        Block b = blockOf(stack);
        if (b == null) {
            return Size.SMALL;
        }
        if (b == Blocks.PUMPKIN || b == Blocks.MELON || b instanceof CarvedPumpkinBlock) {
            return Size.MEDIUM;
        }
        if (b instanceof CandleBlock || b instanceof net.minecraft.world.level.block.LanternBlock
                || b instanceof com.jaquadro.minecraft.gardencollection.block.LanternBlock || b instanceof CandelabraBlock) {
            return Size.SMALL;
        }
        if (b instanceof CropBlock || b instanceof StemBlock || b instanceof DoublePlantBlock || b == Blocks.SUGAR_CANE
                || b == Blocks.CACTUS || b == Blocks.BAMBOO || b instanceof SweetBerryBushBlock || b instanceof NetherWartBlock) {
            return Size.FULL;
        }
        if (b instanceof SaplingBlock || b instanceof GardenSaplingBlock || b instanceof AzaleaBlock
                || b == Blocks.GRASS || b == Blocks.FERN || b == Blocks.DEAD_BUSH) {
            return Size.LARGE;
        }
        if (stack.is(net.minecraft.tags.ItemTags.SMALL_FLOWERS) || b instanceof MushroomBlock || b instanceof NetherSproutsBlock
                || b instanceof RootsBlock || b == Blocks.LILY_PAD) {
            return Size.SMALL;
        }
        return Size.MEDIUM;
    }
}
