package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;
import org.jetbrains.annotations.Nullable;

public class GardenSoilBlock extends Block implements EntityBlock, GardenHost, BonemealableBlock {
    public GardenSoilBlock() {
        super(BlockBehaviour.Properties.of().mapColor(MapColor.DIRT).strength(0.5F).sound(net.minecraft.world.level.block.SoundType.GRAVEL).lightLevel(s -> s.getValue(GardenHost.LIGHT)));
        registerDefaultState(stateDefinition.any().setValue(GardenHost.LIGHT, 0));
    }

    @Override
    protected void createBlockStateDefinition(net.minecraft.world.level.block.state.StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(GardenHost.LIGHT);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new GardenBlockEntity(pos, state);
    }

    @Override
    public int gardenSlots() {
        return 4;
    }

    @Override
    public double plantTop() {
        return 1.0D;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        // only plants / decor are handled here; hoes and everything else fall through to vanilla
        if (hand == InteractionHand.MAIN_HAND && (GardenHelper.acceptsOnSoil(player.getItemInHand(hand)))) {
            return GardenHelper.interact(level, pos, player, hand);
        }
        return InteractionResult.PASS;
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state, boolean client) {
        return GardenHelper.canBonemeal(level, pos, client);
    }

    @Override
    public boolean isBonemealSuccess(Level level, RandomSource random, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource random, BlockPos pos, BlockState state) {
        GardenHelper.applyBonemeal(level, pos, random);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock())) {
            GardenHelper.dropAll(level, pos);
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    /** Hoes turn garden soil into tilled garden soil (replaces the 1.7.10 hoe event). */
    @Nullable
    @Override
    public BlockState getToolModifiedState(BlockState state, UseOnContext context, ToolAction toolAction, boolean simulate) {
        if (toolAction == ToolActions.HOE_TILL && context.getLevel().getBlockState(context.getClickedPos().above()).isAir()) {
            return ModBlocks.GARDEN_FARMLAND.get().defaultBlockState();
        }
        return super.getToolModifiedState(state, context, toolAction, simulate);
    }
}
