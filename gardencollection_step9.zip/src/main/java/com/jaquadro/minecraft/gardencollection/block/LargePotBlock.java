package com.jaquadro.minecraft.gardencollection.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Large pot whose rim connects to neighbouring large pots (the "connecting barriers"). */
public class LargePotBlock extends GardenPotBlock {
    public static final BooleanProperty NORTH = BooleanProperty.create("north");
    public static final BooleanProperty EAST = BooleanProperty.create("east");
    public static final BooleanProperty SOUTH = BooleanProperty.create("south");
    public static final BooleanProperty WEST = BooleanProperty.create("west");

    private static final VoxelShape FLOOR = Block.box(0, 0, 0, 16, 2, 16);
    private static final VoxelShape POSTS = Shapes.or(Block.box(0, 2, 0, 2, 14, 2), Block.box(14, 2, 0, 16, 14, 2),
            Block.box(0, 2, 14, 2, 14, 16), Block.box(14, 2, 14, 16, 14, 16));
    private static final VoxelShape WALL_N = Block.box(2, 2, 0, 14, 14, 2);
    private static final VoxelShape WALL_S = Block.box(2, 2, 14, 14, 14, 16);
    private static final VoxelShape WALL_W = Block.box(0, 2, 2, 2, 14, 14);
    private static final VoxelShape WALL_E = Block.box(14, 2, 2, 16, 14, 14);

    public LargePotBlock() {
        super(4, PotShape.LARGE);
        registerDefaultState(stateDefinition.any().setValue(NORTH, false).setValue(EAST, false).setValue(SOUTH, false).setValue(WEST, false));
    }

    public static BooleanProperty prop(Direction dir) {
        return switch (dir) {
            case NORTH -> NORTH;
            case EAST -> EAST;
            case SOUTH -> SOUTH;
            default -> WEST;
        };
    }

    private static boolean connects(BlockGetter level, BlockPos pos, Direction dir) {
        return level.getBlockState(pos.relative(dir)).getBlock() instanceof LargePotBlock;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(NORTH, EAST, SOUTH, WEST, LIGHT);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockState state = defaultBlockState();
        for (Direction dir : Direction.Plane.HORIZONTAL) {
            state = state.setValue(prop(dir), connects(context.getLevel(), context.getClickedPos(), dir));
        }
        return state;
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (dir.getAxis().isHorizontal()) {
            return state.setValue(prop(dir), neighbor.getBlock() instanceof LargePotBlock);
        }
        return super.updateShape(state, dir, neighbor, level, pos, neighborPos);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        VoxelShape shape = Shapes.or(FLOOR, POSTS);
        if (!state.getValue(NORTH)) shape = Shapes.or(shape, WALL_N);
        if (!state.getValue(SOUTH)) shape = Shapes.or(shape, WALL_S);
        if (!state.getValue(WEST)) shape = Shapes.or(shape, WALL_W);
        if (!state.getValue(EAST)) shape = Shapes.or(shape, WALL_E);
        return shape;
    }

    /** Inner area (x0, z0, x1, z1 in block units) that liquid / soil fill; reaches the edge where pots connect. */
    public static double[] interior(BlockState state) {
        return new double[]{
                state.getValue(WEST) ? 0.0D : 0.125D, state.getValue(NORTH) ? 0.0D : 0.125D,
                state.getValue(EAST) ? 1.0D : 0.875D, state.getValue(SOUTH) ? 1.0D : 0.875D};
    }

    @Override
    public double plantTop() {
        return 0.625D;
    }

    @Override
    public double floorY() {
        return 0.125D;
    }

    @Override
    public double fluidY() {
        return 0.75D;
    }

    @Override
    public int slotMask() {
        return 0x3FFF;
    }
}
