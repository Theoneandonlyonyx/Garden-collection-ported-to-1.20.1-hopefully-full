package com.jaquadro.minecraft.gardencollection.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class WindowBoxBlock extends GardenPotBlock {
    public static final DirectionProperty FACING = net.minecraft.world.level.block.HorizontalDirectionalBlock.FACING;
    private static final VoxelShape NORTH = Block.box(0, 0, 0, 16, 6, 6);
    private static final VoxelShape SOUTH = Block.box(0, 0, 10, 16, 6, 16);
    private static final VoxelShape WEST = Block.box(0, 0, 0, 6, 6, 16);
    private static final VoxelShape EAST = Block.box(10, 0, 0, 16, 6, 16);

    public WindowBoxBlock(int slots, boolean wood) {
        super(slots, PotShape.LARGE, wood
                ? Properties.of().mapColor(MapColor.WOOD).strength(0.8F).sound(SoundType.WOOD).noOcclusion().dynamicShape()
                : Properties.of().mapColor(MapColor.STONE).strength(1.2F).sound(SoundType.STONE).noOcclusion().dynamicShape().requiresCorrectToolForDrops());
        registerDefaultState(defaultBlockState().setValue(FACING, Direction.NORTH));
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return switch (state.getValue(FACING)) {
            case SOUTH -> SOUTH;
            case WEST -> WEST;
            case EAST -> EAST;
            default -> NORTH;
        };
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, LIGHT);
    }

    @Override
    public double plantTop() {
        return 0.34D;
    }

    @Override
    public double floorY() {
        return 0.34D;
    }

    @Override
    public int slotMask() {
        return 0b1101; // NW, centre, NE = three plants in a row
    }

    @Override
    public boolean requiresSubstrate() {
        return false;
    }

    public WindowBoxBlock woodStyle() {
        return this;
    }

    public static SoundType woodSound() {
        return SoundType.WOOD;
    }

    public static MapColor woodColor() {
        return MapColor.WOOD;
    }
}
