package com.jaquadro.minecraft.gardencollection.block.entity;

import com.jaquadro.minecraft.gardencollection.block.GardenConnection;
import com.jaquadro.minecraft.gardencollection.block.GardenHelper;
import com.jaquadro.minecraft.gardencollection.block.GardenSlots;
import com.jaquadro.minecraft.gardencollection.block.GardenHost;
import com.jaquadro.minecraft.gardencollection.block.GardenProxyBlock;
import com.jaquadro.minecraft.gardencollection.registry.ModBlockEntities;
import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.templates.FluidTank;
import net.minecraft.core.Direction;
import org.jetbrains.annotations.Nullable;

/** Holds up to four items (plants and decor) for pots, window boxes, garden soil and tilled soil. */
public class GardenBlockEntity extends BlockEntity {
    private final NonNullList<ItemStack> plants = NonNullList.withSize(com.jaquadro.minecraft.gardencollection.block.GardenSlots.COUNT, ItemStack.EMPTY);
    /** Live block state of the plant in each slot (crop age etc.); null = default state. */
    private final BlockState[] states = new BlockState[com.jaquadro.minecraft.gardencollection.block.GardenSlots.COUNT];

    /** Pots and window boxes hold one bucket of any fluid. */
    private final FluidTank tank = new FluidTank(1000) {
        @Override
        protected void onContentsChanged() {
            changed();
        }
    };
    private final LazyOptional<IFluidHandler> fluidHandler = LazyOptional.of(() -> tank);

    private ItemStack substrate = ItemStack.EMPTY;

    public ItemStack getSubstrate() {
        return substrate;
    }

    public void setSubstrate(ItemStack stack) {
        substrate = stack;
        changed();
    }

    public FluidTank tank() {
        return tank;
    }

    @Override
    public <T> LazyOptional<T> getCapability(Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.FLUID_HANDLER && getBlockState().getBlock() instanceof com.jaquadro.minecraft.gardencollection.block.GardenPotBlock) {
            return fluidHandler.cast();
        }
        return super.getCapability(cap, side);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        fluidHandler.invalidate();
    }

    public GardenBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.GARDEN.get(), pos, state);
    }

    public int slotCount() {
        return GardenSlots.COUNT;
    }

    /** Neighbouring garden host joined to this one, or null. */
    @Nullable
    private GardenBlockEntity attached(int dx, int dz) {
        if (level == null) {
            return null;
        }
        if (level.getBlockEntity(worldPosition.offset(dx, 0, dz)) instanceof GardenBlockEntity other
                && GardenConnection.connects(this, other)) {
            return other;
        }
        return null;
    }

    /** Does this host have the slot, and (for shared edge slots) are all neighbours it needs joined? */
    public boolean isSlotValid(int slot) {
        if (slot < 0 || slot >= GardenSlots.COUNT || !(getBlockState().getBlock() instanceof GardenHost host)) {
            return false;
        }
        if ((host.slotMask() & (1 << slot)) == 0) {
            return false;
        }
        for (int[] m : GardenSlots.shared(slot)) {
            if (attached(m[0], m[1]) == null) {
                return false;
            }
        }
        return true;
    }

    /** Item in a slot, including an item a neighbour stored in the shared spot. */
    public ItemStack getShared(int slot) {
        ItemStack own = plants.get(slot);
        if (!own.isEmpty()) {
            return own;
        }
        for (int[] m : GardenSlots.shared(slot)) {
            GardenBlockEntity n = attached(m[0], m[1]);
            if (n != null && !n.plants.get(m[2]).isEmpty()) {
                return n.plants.get(m[2]);
            }
        }
        return ItemStack.EMPTY;
    }

    public void setShared(int slot, ItemStack stack) {
        for (int[] m : GardenSlots.shared(slot)) {
            GardenBlockEntity n = attached(m[0], m[1]);
            if (n != null && !n.plants.get(m[2]).isEmpty()) {
                n.setPlant(m[2], ItemStack.EMPTY);
            }
        }
        setPlant(slot, stack);
    }

    public boolean canPlaceIn(int slot, ItemStack stack) {
        if (!isSlotValid(slot)) {
            return false;
        }
        if (stack.isEmpty()) {
            return true;
        }
        if (!GardenHelper.accepts(stack) || !GardenHelper.canHostPlant(this, stack)) {
            return false;
        }
        if (slot == GardenSlots.COVER) {
            return GardenSlots.isCover(stack);
        }
        if (slot == GardenSlots.CENTER) {
            return true;
        }
        return GardenSlots.sizeOf(stack) != GardenSlots.Size.FULL;
    }

    /** First free slot that accepts the item, or -1. */
    public int findSlotFor(ItemStack stack) {
        if (GardenSlots.isCover(stack) && canPlaceIn(GardenSlots.COVER, stack) && getShared(GardenSlots.COVER).isEmpty()) {
            return GardenSlots.COVER;
        }
        for (int slot : GardenSlots.ORDER) {
            if (canPlaceIn(slot, stack) && getShared(slot).isEmpty()) {
                return slot;
            }
        }
        return -1;
    }

    public ItemStack getPlant(int slot) {
        return plants.get(slot);
    }

    public void setPlant(int slot, ItemStack stack) {
        plants.set(slot, stack);
        states[slot] = null;
        changed();
    }

    public boolean hasAnyPlant() {
        for (ItemStack stack : plants) {
            if (!stack.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /** State of a growing plant in this slot, or null if the slot is empty or holds decor / a non-block. */
    @Nullable
    public BlockState getPlantState(int slot) {
        ItemStack stack = plants.get(slot);
        if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem blockItem) || GardenHelper.isDecorItem(stack)) {
            return null;
        }
        BlockState state = states[slot];
        if (state == null || state.getBlock() != blockItem.getBlock()) {
            state = blockItem.getBlock().defaultBlockState();
        }
        return state;
    }

    /** State used for drawing: plants use their live state, decor its default state. */
    @Nullable
    public BlockState getRenderState(int slot) {
        ItemStack stack = plants.get(slot);
        if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem blockItem)) {
            return null;
        }
        BlockState live = getPlantState(slot);
        if (live != null) {
            return live;
        }
        BlockState decor = blockItem.getBlock().defaultBlockState();
        if (decor.hasProperty(net.minecraft.world.level.block.CandleBlock.LIT)) {
            decor = decor.setValue(net.minecraft.world.level.block.CandleBlock.LIT, true);
        }
        return decor;
    }

    public void setPlantState(int slot, BlockState state) {
        states[slot] = state;
        changed();
    }

    private void changed() {
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
            if (!level.isClientSide) {
                updateLight();
                syncProxy();
            }
        }
    }

    /** Light level of the host = brightest item or fluid inside. */
    public int computeLight() {
        int best = 0;
        for (int i = 0; i < slotCount(); i++) {
            ItemStack stack = plants.get(i);
            if (stack.isEmpty() || !(stack.getItem() instanceof BlockItem blockItem)) {
                continue;
            }
            net.minecraft.world.level.block.Block block = blockItem.getBlock();
            int light;
            if (block instanceof net.minecraft.world.level.block.CandleBlock) {
                light = 3;
            } else if (block instanceof com.jaquadro.minecraft.gardencollection.block.LanternBlock) {
                light = 15;
            } else if (block instanceof com.jaquadro.minecraft.gardencollection.block.CandelabraBlock) {
                light = 12;
            } else {
                light = block.defaultBlockState().getLightEmission();
            }
            best = Math.max(best, light);
        }
        if (!tank.getFluid().isEmpty()) {
            best = Math.max(best, tank.getFluid().getFluid().getFluidType().getLightLevel(tank.getFluid()));
        }
        return Math.min(15, best);
    }

    private void updateLight() {
        BlockState state = getBlockState();
        if (state.hasProperty(GardenHost.LIGHT)) {
            int light = computeLight();
            if (state.getValue(GardenHost.LIGHT) != light) {
                level.setBlock(worldPosition, state.setValue(GardenHost.LIGHT, light), 3);
            }
        }
    }

    /** Keeps the invisible proxy block above the host in step with the contents. */
    public void syncProxy() {
        if (level == null || getBlockState().getBlock() instanceof GardenProxyBlock) {
            return;
        }
        BlockPos above = worldPosition.above();
        BlockState there = level.getBlockState(above);
        if (hasAnyPlant()) {
            if (there.isAir()) {
                level.setBlock(above, ModBlocks.GARDEN_PROXY.get().defaultBlockState(), 2 | 16 | 32);
            }
        } else if (there.getBlock() instanceof GardenProxyBlock) {
            level.setBlock(above, Blocks.AIR.defaultBlockState(), 2 | 16 | 32);
        }
    }

    public NonNullList<ItemStack> plants() {
        return plants;
    }

    public boolean stillValid(Player player) {
        if (level == null || level.getBlockEntity(worldPosition) != this) {
            return false;
        }
        return player.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) <= 64.0;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ContainerHelper.saveAllItems(tag, plants);
        ListTag list = new ListTag();
        for (int i = 0; i < states.length; i++) {
            if (states[i] != null) {
                CompoundTag entry = new CompoundTag();
                entry.putByte("Slot", (byte) i);
                entry.put("State", NbtUtils.writeBlockState(states[i]));
                list.add(entry);
            }
        }
        tag.put("PlantStates", list);
        tank.writeToNBT(tag);
        if (!substrate.isEmpty()) {
            tag.put("Substrate", substrate.save(new CompoundTag()));
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        for (int i = 0; i < plants.size(); i++) {
            plants.set(i, ItemStack.EMPTY);
            states[i] = null;
        }
        ContainerHelper.loadAllItems(tag, plants);
        tank.readFromNBT(tag);
        substrate = tag.contains("Substrate") ? ItemStack.of(tag.getCompound("Substrate")) : ItemStack.EMPTY;
        ListTag list = tag.getList("PlantStates", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            int slot = entry.getByte("Slot");
            if (slot >= 0 && slot < states.length) {
                states[slot] = NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), entry.getCompound("State"));
            }
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
