package com.jaquadro.minecraft.gardencollection.client.renderer;

import com.jaquadro.minecraft.gardencollection.block.GardenHelper;
import com.jaquadro.minecraft.gardencollection.block.GardenHost;
import com.jaquadro.minecraft.gardencollection.block.GardenPotBlock;
import com.jaquadro.minecraft.gardencollection.block.GardenSlots;
import com.jaquadro.minecraft.gardencollection.block.LargePotBlock;
import com.jaquadro.minecraft.gardencollection.block.WindowBoxBlock;
import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.Direction;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.client.extensions.common.IClientFluidTypeExtensions;
import net.minecraftforge.fluids.FluidStack;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Draws soil, liquid, plants and decor of a garden host. Plants are drawn at their normal size. */
public class GardenBlockEntityRenderer implements BlockEntityRenderer<GardenBlockEntity> {
    private final BlockRenderDispatcher blockRenderer;

    public GardenBlockEntityRenderer(BlockEntityRendererProvider.Context context) {
        this.blockRenderer = context.getBlockRenderDispatcher();
    }

    /** Pots / soil are solid blocks, so their own light is 0: use the brightest neighbouring light instead. */
    private static int lightFor(GardenBlockEntity be, int own) {
        if (be.getLevel() == null) {
            return own;
        }
        int above = LevelRenderer.getLightColor(be.getLevel(), be.getBlockPos().above());
        int block = Math.max(LightTexture.block(own), LightTexture.block(above));
        int sky = Math.max(LightTexture.sky(own), LightTexture.sky(above));
        return LightTexture.pack(block, sky);
    }

    @Override
    public void render(GardenBlockEntity be, float partialTick, PoseStack pose, MultiBufferSource buffers, int ownLight, int overlay) {
        BlockState hostState = be.getBlockState();
        if (!(hostState.getBlock() instanceof GardenHost host)) {
            return;
        }
        int light = lightFor(be, ownLight);
        boolean substrate = !be.getSubstrate().isEmpty();
        double[] in = interior(hostState);

        // soil
        if (substrate && host.plantTop() > host.floorY() && be.getSubstrate().getItem() instanceof BlockItem soil) {
            pose.pushPose();
            pose.translate(in[0], host.floorY(), in[1]);
            pose.scale((float) (in[2] - in[0]), (float) (host.plantTop() - host.floorY()), (float) (in[3] - in[1]));
            blockRenderer.renderSingleBlock(soil.getBlock().defaultBlockState(), pose, buffers, light, OverlayTexture.NO_OVERLAY);
            pose.popPose();
        }

        // liquid
        FluidStack fluid = be.tank().getFluid();
        if (!fluid.isEmpty() && hostState.getBlock() instanceof GardenPotBlock) {
            drawFluid(fluid, new AABB(in[0], 0, in[1], in[2], 0, in[3]), host.fluidY(), pose, buffers, light);
        }

        // plants and decor
        double top = host.plantTop();
        if (host.requiresSubstrate() && !substrate && fluid.isEmpty()) {
            top = host.floorY();
        }
        int count = be.slotCount();
        for (int i = 0; i < count; i++) {
            BlockState state = be.getRenderState(i);
            ItemStack stack = be.getPlant(i);
            if (state == null) {
                continue;
            }
            if (!be.isSlotValid(i)) {
                continue;
            }
            double[] p = position(hostState, i);
            float scale = hostState.getBlock() instanceof WindowBoxBlock ? 0.5F : (float) decorScale(stack);
            int itemLight = light;
            int emit = state.getLightEmission();
            if (emit > 0) {
                itemLight = LightTexture.pack(Math.max(LightTexture.block(light), emit), LightTexture.sky(light));
            }
            pose.pushPose();
            pose.translate(p[0] - scale / 2.0D, top, p[1] - scale / 2.0D);
            pose.scale(scale, scale, scale);
            blockRenderer.renderSingleBlock(state, pose, buffers, itemLight, OverlayTexture.NO_OVERLAY);
            if (state.getBlock() instanceof DoublePlantBlock && state.hasProperty(DoublePlantBlock.HALF)) {
                pose.translate(0.0D, 1.0D, 0.0D);
                blockRenderer.renderSingleBlock(state.setValue(DoublePlantBlock.HALF, DoubleBlockHalf.UPPER), pose, buffers, itemLight, OverlayTexture.NO_OVERLAY);
            }
            pose.popPose();
        }
    }

    /** Plants and lanterns / candles keep their normal size; only full-block decor is shrunk. */
    private static double decorScale(ItemStack stack) {
        if (GardenHelper.isDecorItem(stack) && stack.getItem() instanceof BlockItem item) {
            Block block = item.getBlock();
            if (block == Blocks.PUMPKIN || block == Blocks.MELON || block instanceof net.minecraft.world.level.block.CarvedPumpkinBlock) {
                return 0.5D;
            }
        }
        return 1.0D;
    }

    private static double[] interior(BlockState state) {
        if (state.getBlock() instanceof LargePotBlock) {
            return LargePotBlock.interior(state);
        }
        if (state.getBlock() instanceof WindowBoxBlock) {
            return new double[]{0.0625D, 0.0625D, 0.9375D, 0.9375D};
        }
        if (state.getBlock() instanceof GardenPotBlock pot) {
            AABB b = pot.potShape().shape.bounds();
            return new double[]{b.minX + 0.0625D, b.minZ + 0.0625D, b.maxX - 0.0625D, b.maxZ - 0.0625D};
        }
        return new double[]{0.0D, 0.0D, 1.0D, 1.0D};
    }

    private static void drawFluid(FluidStack fluid, AABB box, double y, PoseStack pose, MultiBufferSource buffers, int light) {
        IClientFluidTypeExtensions ext = IClientFluidTypeExtensions.of(fluid.getFluid());
        TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(ext.getStillTexture(fluid));
        int color = ext.getTintColor(fluid);
        float a = ((color >> 24) & 255) / 255.0F;
        float r = ((color >> 16) & 255) / 255.0F;
        float g = ((color >> 8) & 255) / 255.0F;
        float b = (color & 255) / 255.0F;
        if (a == 0.0F) {
            a = 1.0F;
        }
        float x0 = (float) box.minX, x1 = (float) box.maxX;
        float z0 = (float) box.minZ, z1 = (float) box.maxZ;
        float yy = (float) y;
        float u0 = sprite.getU(x0 * 16.0F), u1 = sprite.getU(x1 * 16.0F);
        float v0 = sprite.getV(z0 * 16.0F), v1 = sprite.getV(z1 * 16.0F);
        VertexConsumer vc = buffers.getBuffer(RenderType.translucent());
        Matrix4f m = pose.last().pose();
        Matrix3f n = pose.last().normal();
        vc.vertex(m, x0, yy, z0).color(r, g, b, a).uv(u0, v0).uv2(light).normal(n, 0, 1, 0).endVertex();
        vc.vertex(m, x0, yy, z1).color(r, g, b, a).uv(u0, v1).uv2(light).normal(n, 0, 1, 0).endVertex();
        vc.vertex(m, x1, yy, z1).color(r, g, b, a).uv(u1, v1).uv2(light).normal(n, 0, 1, 0).endVertex();
        vc.vertex(m, x1, yy, z0).color(r, g, b, a).uv(u1, v0).uv2(light).normal(n, 0, 1, 0).endVertex();
    }

    /** x, z centre of a slot, taken from the original mod's slot offsets. */
    private static double[] position(BlockState state, int slot) {
        double x = GardenSlots.X[slot];
        double z = GardenSlots.Z[slot];
        if (state.getBlock() instanceof WindowBoxBlock) {
            Direction facing = state.getValue(WindowBoxBlock.FACING);
            double across = (facing == Direction.NORTH || facing == Direction.WEST) ? 0.19D : 0.81D;
            double along = slot == GardenSlots.NW ? 0.2D : slot == GardenSlots.NE ? 0.8D : 0.5D;
            return facing.getAxis() == Direction.Axis.X ? new double[]{across, along} : new double[]{along, across};
        }
        return new double[]{x, z};
    }
}
