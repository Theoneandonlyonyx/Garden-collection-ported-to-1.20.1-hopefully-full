package com.jaquadro.minecraft.gardencollection.client.screen;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import com.jaquadro.minecraft.gardencollection.block.GardenSlots;
import com.jaquadro.minecraft.gardencollection.inventory.GardenMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class GardenScreen extends AbstractContainerScreen<GardenMenu> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(GardenCollection.MODID, "textures/gui/garden_layout.png");

    public GardenScreen(GardenMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 204;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
        // grey out every field this block can't use (no neighbour joined / not part of this block type)
        for (int slot = 0; slot < GardenSlots.COUNT; slot++) {
            if (slot == GardenSlots.COVER || menu.garden().isSlotValid(slot)) {
                continue;
            }
            graphics.blit(TEXTURE, leftPos + GardenMenu.STORAGE_X + 18 * GardenSlots.GUI_X[slot],
                    topPos + GardenMenu.STORAGE_Y + 18 * GardenSlots.GUI_Y[slot], 176, 0, 16, 16);
        }
    }
}
