package com.jaquadro.minecraft.gardencollection.inventory;

import com.jaquadro.minecraft.gardencollection.block.GardenSlots;
import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** Live view on a garden host: 14 plant slots (shared edges included) plus the soil slot. */
public class GardenContainer implements Container {
    public static final int SUBSTRATE = GardenSlots.COUNT;
    private final GardenBlockEntity garden;

    public GardenContainer(GardenBlockEntity garden) {
        this.garden = garden;
    }

    @Override
    public int getContainerSize() {
        return GardenSlots.COUNT + 1;
    }

    @Override
    public boolean isEmpty() {
        return !garden.hasAnyPlant() && garden.getSubstrate().isEmpty();
    }

    @Override
    public ItemStack getItem(int slot) {
        return slot == SUBSTRATE ? garden.getSubstrate() : garden.getShared(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack current = getItem(slot);
        if (current.isEmpty()) {
            return ItemStack.EMPTY;
        }
        ItemStack out = current.copy();
        setItem(slot, ItemStack.EMPTY);
        return out;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return removeItem(slot, 1);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        if (slot == SUBSTRATE) {
            garden.setSubstrate(stack);
        } else {
            garden.setShared(slot, stack);
        }
    }

    @Override
    public void setChanged() {
        garden.setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        return garden.stillValid(player);
    }

    @Override
    public void clearContent() {
    }
}
