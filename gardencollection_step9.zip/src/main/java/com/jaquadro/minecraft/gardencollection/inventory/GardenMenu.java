package com.jaquadro.minecraft.gardencollection.inventory;

import com.jaquadro.minecraft.gardencollection.block.GardenHelper;
import com.jaquadro.minecraft.gardencollection.block.GardenHost;
import com.jaquadro.minecraft.gardencollection.block.GardenProxyBlock;
import com.jaquadro.minecraft.gardencollection.block.GardenSlots;
import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import com.jaquadro.minecraft.gardencollection.registry.ModMenus;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** The stuffing GUI: slots laid out exactly like the plants stand in the block. */
public class GardenMenu extends BaseMenu {
    public static final int STORAGE_X = 44;
    public static final int STORAGE_Y = 18;
    private static final int SUBSTRATE_X = 17;
    private static final int SUBSTRATE_Y = 86;
    private static final int COVER_X = 143;
    private static final int COVER_Y = 86;

    private final GardenBlockEntity garden;
    private final GardenContainer container;
    private final int gardenSlotCount;

    public GardenMenu(int id, Inventory playerInv, FriendlyByteBuf buf) {
        this(id, playerInv, (GardenBlockEntity) playerInv.player.level().getBlockEntity(buf.readBlockPos()));
    }

    public GardenMenu(int id, Inventory playerInv, GardenBlockEntity garden) {
        super(ModMenus.GARDEN.get(), id);
        this.garden = garden;
        this.container = new GardenContainer(garden);

        if (garden.isSlotValid(GardenSlots.COVER)) {
            addSlot(new PlantSlot(GardenSlots.COVER, COVER_X, COVER_Y));
        }
        for (int slot : new int[]{0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13}) {
            if (garden.isSlotValid(slot)) {
                addSlot(new PlantSlot(slot, STORAGE_X + 18 * GardenSlots.GUI_X[slot], STORAGE_Y + 18 * GardenSlots.GUI_Y[slot]));
            }
        }
        if (garden.getBlockState().getBlock() instanceof GardenHost host && host.requiresSubstrate()) {
            addSlot(new Slot(container, GardenContainer.SUBSTRATE, SUBSTRATE_X, SUBSTRATE_Y) {
                @Override
                public boolean mayPlace(ItemStack stack) {
                    return GardenHelper.isSubstrate(stack);
                }

                @Override
                public int getMaxStackSize() {
                    return 1;
                }
            });
        }
        this.gardenSlotCount = slots.size();
        addPlayerSlots(playerInv, 8, 122);
    }

    public GardenBlockEntity garden() {
        return garden;
    }

    private class PlantSlot extends Slot {
        private final int plantSlot;

        PlantSlot(int plantSlot, int x, int y) {
            super(container, plantSlot, x, y);
            this.plantSlot = plantSlot;
        }

        @Override
        public boolean mayPlace(ItemStack stack) {
            return garden.canPlaceIn(plantSlot, stack);
        }

        @Override
        public int getMaxStackSize() {
            return 1;
        }
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (slot == null || !slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack result = stack.copy();
        if (index < gardenSlotCount) {
            if (!moveItemStackTo(stack, gardenSlotCount, slots.size(), true)) {
                return ItemStack.EMPTY;
            }
            slot.set(ItemStack.EMPTY);
            return result;
        }
        for (int i = 0; i < gardenSlotCount; i++) {
            Slot target = slots.get(i);
            if (!target.hasItem() && target.mayPlace(stack)) {
                ItemStack one = stack.copy();
                one.setCount(1);
                target.set(one);
                stack.shrink(1);
                slot.setChanged();
                return result;
            }
        }
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return garden.stillValid(player);
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        // a trowel bed that was opened but never planted disappears again
        if (!player.level().isClientSide && garden.getBlockState().getBlock() instanceof GardenProxyBlock
                && garden.getBlockState().getValue(GardenProxyBlock.HOSTED) && !garden.hasAnyPlant()) {
            player.level().removeBlock(garden.getBlockPos(), false);
        }
    }
}
