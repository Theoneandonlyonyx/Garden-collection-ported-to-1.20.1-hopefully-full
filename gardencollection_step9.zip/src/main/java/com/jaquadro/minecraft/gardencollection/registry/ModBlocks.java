package com.jaquadro.minecraft.gardencollection.registry;

import com.jaquadro.minecraft.gardencollection.GardenCollection;
import com.jaquadro.minecraft.gardencollection.block.*;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChainBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, GardenCollection.MODID);
    /** Every block of the mod by registry name (insertion ordered). */
    public static final Map<String, RegistryObject<Block>> ALL = new LinkedHashMap<>();

    public static final List<String> WOODS = List.of("oak", "spruce", "birch", "jungle", "acacia", "dark_oak");
    public static final List<String> CHAIN_METALS = List.of("iron", "wrought_iron", "gold", "rust", "moss", "rope");
    public static final List<String> METAL_LATTICES = List.of("iron", "wrought_iron", "rust", "moss");

    private static RegistryObject<Block> reg(String name, Supplier<? extends Block> supplier) {
        RegistryObject<Block> object = BLOCKS.register(name, () -> (Block) supplier.get());
        ALL.put(name, object);
        return object;
    }

    // ---- Garden Core
    public static final RegistryObject<Block> GARDEN_SOIL = reg("garden_soil", GardenSoilBlock::new);
    public static final RegistryObject<Block> GARDEN_FARMLAND = reg("garden_farmland", GardenFarmlandBlock::new);
    public static final RegistryObject<Block> GARDEN_PROXY = reg("garden_proxy", GardenProxyBlock::new);
    public static final RegistryObject<Block> SMALL_FIRE = reg("small_fire", SmallFireBlock::new);
    public static final RegistryObject<Block> COMPOST_BIN = reg("compost_bin", CompostBinBlock::new);

    // ---- Garden Containers
    public static final RegistryObject<Block> POTTERY_TABLE = reg("pottery_table", PotteryTableBlock::new);
    public static final RegistryObject<Block> RAW_LARGE_POT = reg("raw_large_pot", RawPotBlock::new);
    public static final RegistryObject<Block> LARGE_POT = reg("large_pot", () -> new LargePotBlock());
    public static final RegistryObject<Block> MEDIUM_POT = reg("medium_pot", () -> new GardenPotBlock(1, PotShape.MEDIUM));
    public static final RegistryObject<Block> DECORATIVE_POT = reg("decorative_pot", () -> new GardenPotBlock(1, PotShape.DECORATIVE));

    // ---- Garden Stuff
    public static final RegistryObject<Block> BLOOMERY_FURNACE = reg("bloomery_furnace", BloomeryFurnaceBlock::new);
    public static final RegistryObject<Block> CHARCOAL_BLOCK = reg("charcoal_block",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(5.0F, 6.0F).sound(SoundType.STONE).requiresCorrectToolForDrops()));
    public static final RegistryObject<Block> WROUGHT_IRON_BLOCK = reg("wrought_iron_block",
            () -> new Block(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(5.0F, 10.0F).sound(SoundType.METAL).requiresCorrectToolForDrops()));
    public static final RegistryObject<Block> WROUGHT_IRON_BARS = reg("wrought_iron_bars",
            () -> new IronBarsBlock(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLACK).strength(5.0F, 6.0F).sound(SoundType.METAL).requiresCorrectToolForDrops().noOcclusion()));
    public static final RegistryObject<Block> LANTERN = reg("lantern", LanternBlock::new);
    public static final RegistryObject<Block> HOOP = reg("hoop", HoopBlock::new);
    public static final RegistryObject<Block> ROOT_COVER = reg("root_cover", RootCoverBlock::new);

    // ---- Garden Trees
    public static final RegistryObject<Block> IVY = reg("ivy", IvyBlock::new);
    public static final RegistryObject<Block> STRANGE_PLANT = reg("strange_plant", StrangePlantBlock::new);
    public static final RegistryObject<Block> CANDELILLA = reg("candelilla", CandelillaBlock::new);
    public static final RegistryObject<Block> PINE_SAPLING = reg("pine_sapling", () -> new GardenSaplingBlock(GardenSaplingBlock.Kind.PINE));
    public static final RegistryObject<Block> SWAMP_SAPLING = reg("swamp_sapling", () -> new GardenSaplingBlock(GardenSaplingBlock.Kind.SWAMP));
    public static final RegistryObject<Block> TALL_BIRCH_SAPLING = reg("tall_birch_sapling", () -> new GardenSaplingBlock(GardenSaplingBlock.Kind.TALL_BIRCH));

    static {
        // dyed pots
        for (DyeColor dye : DyeColor.values()) {
            reg("large_pot_" + dye.getName(), () -> new LargePotBlock());
            reg("medium_pot_" + dye.getName(), () -> new GardenPotBlock(1, PotShape.MEDIUM));
        }
        // window boxes
        for (String wood : WOODS) {
            reg("window_box_" + wood, () -> new WindowBoxBlock(3, true));
        }
        reg("window_box_stone", () -> new WindowBoxBlock(3, false));
        reg("window_box_brick", () -> new WindowBoxBlock(3, false));

        // candelabras
        for (int i = 1; i <= 3; i++) {
            final int candles = i;
            reg("candelabra_" + i, () -> new CandelabraBlock(candles));
        }

        // moss bricks (stages 2-4 of mossy, 1-4 of cracked mossy)
        for (int i = 2; i <= 4; i++) {
            reg("moss_brick_mossy_" + i, () -> new Block(BlockBehaviour.Properties.copy(Blocks.MOSSY_STONE_BRICKS)));
        }
        for (int i = 1; i <= 4; i++) {
            reg("moss_brick_cracked_mossy_" + i, () -> new Block(BlockBehaviour.Properties.copy(Blocks.MOSSY_STONE_BRICKS)));
        }

        // thin logs, thin log fences, wooden lattices
        for (String wood : WOODS) {
            reg("thin_log_" + wood, ThinLogBlock::new);
            reg("thin_log_fence_" + wood, () -> new FenceBlock(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(2.0F, 3.0F).sound(SoundType.WOOD).ignitedByLava()));
            reg("wood_lattice_" + wood, () -> new IronBarsBlock(BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(1.0F).sound(SoundType.WOOD).noOcclusion().ignitedByLava()));
        }

        // metal lattices
        for (String metal : METAL_LATTICES) {
            reg("lattice_" + metal, () -> new IronBarsBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.0F, 6.0F).sound(SoundType.METAL).noOcclusion()));
        }

        // chains
        for (String metal : CHAIN_METALS) {
            reg("chain_light_" + metal, () -> new ChainBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(2.0F, 4.0F).sound(SoundType.CHAIN).noOcclusion()));
            reg("chain_heavy_" + metal, () -> new ChainBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3.0F, 6.0F).sound(SoundType.CHAIN).noOcclusion()));
        }
    }

    /** All blocks that carry a {@code GardenBlockEntity} (pots and window boxes). */
    public static Block[] gardenBlocks() {
        List<Block> list = new ArrayList<>();
        for (RegistryObject<Block> object : ALL.values()) {
            Block block = object.get();
            if (block instanceof GardenHost) {
                list.add(block);
            }
        }
        return list.toArray(new Block[0]);
    }

    private ModBlocks() {}
}
