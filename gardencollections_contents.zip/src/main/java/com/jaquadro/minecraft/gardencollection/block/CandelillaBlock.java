package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.common.IShearable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class CandelillaBlock extends CropBlock implements IShearable {
    private static final VoxelShape[] SHAPE = new VoxelShape[]{
            Block.box(4, 0, 4, 12, 4, 12),
            Block.box(4, 0, 4, 12, 6, 12),
            Block.box(3, 0, 3, 13, 8, 13),
            Block.box(3, 0, 3, 13, 10, 13),
            Block.box(2, 0, 2, 14, 12, 14),
            Block.box(2, 0, 2, 14, 14, 14),
            Block.box(2, 0, 2, 14, 15, 14),
            Block.box(2, 0, 2, 14, 16, 14)
    };

    public CandelillaBlock() {
        super(Properties.copy(Blocks.WHEAT).mapColor(net.minecraft.world.level.material.MapColor.PLANT));
    }

    @Override
    protected ItemLike getBaseSeedId() {
        return ModItems.CANDELILLA_SEEDS.get();
    }

    @Override
    protected boolean mayPlaceOn(BlockState state, BlockGetter level, BlockPos pos) {
        return state.is(Blocks.FARMLAND) || state.getBlock() instanceof GardenFarmlandBlock || state.is(net.minecraft.tags.BlockTags.DIRT) || state.is(Blocks.SAND) || state.is(Blocks.RED_SAND);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE[state.getValue(AGE)];
    }

    @Override
    public boolean isShearable(@NotNull ItemStack item, Level level, BlockPos pos) {
        return true;
    }

    @Override
    public @NotNull List<ItemStack> onSheared(@Nullable net.minecraft.world.entity.player.Player player, @NotNull ItemStack item, net.minecraft.world.level.Level level, BlockPos pos, int fortune) {
        return List.of(new ItemStack(this));
    }

    @Override
    public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
        ItemStack tool = builder.getOptionalParameter(LootContextParams.TOOL);
        if (tool != null && tool.is(net.minecraft.world.item.Items.SHEARS)) {
            return List.of(new ItemStack(this));
        }
        int age = state.getValue(AGE);
        if (age >= getMaxAge()) {
            return List.of(new ItemStack(ModItems.CANDELILLA.get()), new ItemStack(ModItems.CANDELILLA_SEEDS.get(), 1 + builder.getLevel().getRandom().nextInt(2)));
        }
        return List.of(new ItemStack(ModItems.CANDELILLA_SEEDS.get()));
    }

    // keep import used if the seed method name differs at compile time
    @SuppressWarnings("unused")
    private Item seedFallback() {
        return ModItems.CANDELILLA_SEEDS.get();
    }
}
