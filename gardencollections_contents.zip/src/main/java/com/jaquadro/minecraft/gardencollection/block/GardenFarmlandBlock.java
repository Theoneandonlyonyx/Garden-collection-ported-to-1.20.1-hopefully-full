package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraftforge.common.FarmlandWaterManager;

import java.util.Random;

public class GardenFarmlandBlock extends FarmBlock {
    public GardenFarmlandBlock() {
        super(Properties.copy(net.minecraft.world.level.block.Blocks.FARMLAND));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
    }

    @Override
    public void fallOn(Level level, BlockState state, BlockPos pos, Entity entity, float fallDistance) {
        super.fallOn(level, state, pos, entity, fallDistance);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, net.minecraft.util.RandomSource random) {
        int moisture = state.getValue(MOISTURE);
        if (!isNearWater(level, pos) && !level.isRainingAt(pos.above())) {
            if (moisture > 0) {
                level.setBlock(pos, state.setValue(MOISTURE, moisture - 1), 2);
            } else if (!level.getBlockState(pos.above()).isSolidRender(level, pos.above())) {
                level.setBlockAndUpdate(pos, ModBlocks.GARDEN_SOIL.get().defaultBlockState());
            }
        } else if (moisture < 7) {
            level.setBlock(pos, state.setValue(MOISTURE, 7), 2);
        }
    }

    private static boolean isNearWater(Level level, BlockPos pos) {
        for (BlockPos nearby : BlockPos.betweenClosed(pos.offset(-4, 0, -4), pos.offset(4, 1, 4))) {
            if (level.getBlockState(nearby).getFluidState().is(net.minecraft.tags.FluidTags.WATER) || FarmlandWaterManager.hasBlockWaterTicket(level, nearby)) {
                return true;
            }
        }
        return false;
    }
}
