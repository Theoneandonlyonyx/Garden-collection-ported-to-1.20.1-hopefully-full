package com.jaquadro.minecraft.gardencollection.block;

import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import com.jaquadro.minecraft.gardencollection.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public class GardenPotBlock extends BaseEntityBlock {
    private final int slots;
    private final PotShape potShape;

    public GardenPotBlock(int slots, PotShape potShape) {
        this(slots, potShape, Properties.of().mapColor(MapColor.TERRACOTTA_ORANGE).strength(0.6F).sound(SoundType.STONE).noOcclusion().dynamicShape());
    }

    public GardenPotBlock(int slots, PotShape potShape, BlockBehaviour.Properties properties) {
        super(properties);
        this.slots = slots;
        this.potShape = potShape;
    }

    public int slots() {
        return slots;
    }

    public PotShape potShape() {
        return potShape;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return potShape.shape;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new GardenBlockEntity(pos, state);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        BlockEntity be = level.getBlockEntity(pos);
        if (!(be instanceof GardenBlockEntity garden)) {
            return InteractionResult.PASS;
        }
        ItemStack held = player.getItemInHand(hand);
        if (held.isEmpty()) {
            for (int i = garden.slotCount() - 1; i >= 0; i--) {
                ItemStack plant = garden.getPlant(i);
                if (!plant.isEmpty()) {
                    if (!level.isClientSide) {
                        if (!player.addItem(plant)) {
                            player.drop(plant, false);
                        }
                        garden.setPlant(i, ItemStack.EMPTY);
                    }
                    return InteractionResult.sidedSuccess(level.isClientSide);
                }
            }
            return InteractionResult.PASS;
        }
        if (!isPlant(held)) {
            return InteractionResult.PASS;
        }
        for (int i = 0; i < garden.slotCount(); i++) {
            if (garden.getPlant(i).isEmpty()) {
                if (!level.isClientSide) {
                    ItemStack one = held.copy();
                    one.setCount(1);
                    garden.setPlant(i, one);
                    if (!player.getAbilities().instabuild) {
                        held.shrink(1);
                    }
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return InteractionResult.PASS;
    }

    public static boolean isPlant(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        Block block = blockItem.getBlock();
        return block instanceof BushBlock || block instanceof CropBlock || block instanceof SaplingBlock || block instanceof DoublePlantBlock || block instanceof net.minecraft.world.level.block.FlowerBlock;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock())) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof GardenBlockEntity garden) {
                for (int i = 0; i < garden.slotCount(); i++) {
                    Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), garden.getPlant(i));
                }
            }
        }
        super.onRemove(state, level, pos, newState, moving);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return null;
    }

    @SuppressWarnings("unused")
    private static Direction unused() {
        return Direction.UP;
    }

    @SuppressWarnings("unused")
    private static EntityBlock marker() {
        return null;
    }

    public static BlockEntityType<GardenBlockEntity> typeOrNull() {
        return ModBlockEntities.GARDEN.get();
    }
}
