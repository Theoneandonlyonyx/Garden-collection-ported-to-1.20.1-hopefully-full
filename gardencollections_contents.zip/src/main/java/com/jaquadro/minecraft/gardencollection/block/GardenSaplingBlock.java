package com.jaquadro.minecraft.gardencollection.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.grower.TreeGrower;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.material.MapColor;

public class GardenSaplingBlock extends SaplingBlock {
    public enum Kind implements StringRepresentable {
        PINE("pine"),
        SWAMP("swamp"),
        TALL_BIRCH("tallbirch");

        private final String name;

        Kind(String name) {
            this.name = name;
        }

        @Override
        public String getSerializedName() {
            return name;
        }
    }

    public static final EnumProperty<Kind> KIND = EnumProperty.create("kind", Kind.class);

    public GardenSaplingBlock() {
        super(TreeGrower.OAK, Properties.of().mapColor(MapColor.PLANT).noCollission().randomTicks().instabreak().sound(SoundType.GRASS));
        registerDefaultState(defaultBlockState().setValue(KIND, Kind.PINE));
    }

    @Override
    public void advanceTree(ServerLevel level, BlockPos pos, BlockState state, RandomSource random) {
        if (state.getValue(STAGE) == 0) {
            level.setBlock(pos, state.cycle(STAGE), 4);
            return;
        }
        TreeGrower grower = switch (state.getValue(KIND)) {
            case PINE -> TreeGrower.SPRUCE;
            case SWAMP -> TreeGrower.OAK;
            case TALL_BIRCH -> TreeGrower.BIRCH;
        };
        grower.growTree(level, level.getChunkSource().getGenerator(), pos, state, random);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(KIND);
    }
}
