package com.jaquadro.minecraft.gardencollection.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public class GardenSoilBlock extends Block {
    public GardenSoilBlock() {
        super(BlockBehaviour.Properties.of().mapColor(MapColor.DIRT).strength(0.5F).sound(net.minecraft.world.level.block.SoundType.GRAVEL));
    }
}
