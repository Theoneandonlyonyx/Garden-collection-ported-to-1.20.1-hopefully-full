package com.jaquadro.minecraft.gardencollection.block.entity;

import com.jaquadro.minecraft.gardencollection.block.GardenPotBlock;
import com.jaquadro.minecraft.gardencollection.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class GardenBlockEntity extends BlockEntity {
    private final NonNullList<ItemStack> plants = NonNullList.withSize(4, ItemStack.EMPTY);

    public GardenBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.GARDEN.get(), pos, state);
    }

    public int slotCount() {
        if (getBlockState().getBlock() instanceof GardenPotBlock pot) {
            return Math.min(4, pot.slots());
        }
        return 1;
    }

    public ItemStack getPlant(int slot) {
        return plants.get(slot);
    }

    public void setPlant(int slot, ItemStack stack) {
        plants.set(slot, stack);
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    public NonNullList<ItemStack> plants() {
        return plants;
    }

    public boolean stillValid(Player player) {
        if (level == null || level.getBlockEntity(worldPosition) != this) {
            return false;
        }
        return player.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5, worldPosition.getZ() + 0.5) <= 64.0;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ContainerHelper.saveAllItems(tag, plants);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        plants.clear();
        for (int i = 0; i < plants.size(); i++) {
            plants.set(i, ItemStack.EMPTY);
        }
        ContainerHelper.loadAllItems(tag, plants);
    }

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
