package com.jaquadro.minecraft.gardencollection.inventory;

import com.jaquadro.minecraft.gardencollection.block.entity.BloomeryBlockEntity;
import com.jaquadro.minecraft.gardencollection.registry.ModMenus;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class BloomeryMenu extends AbstractContainerMenu {
    private final BloomeryBlockEntity furnace;
    private final ContainerData data;

    public BloomeryMenu(int id, Inventory playerInv, FriendlyByteBuf buf) {
        this(id, playerInv, (BloomeryBlockEntity) playerInv.player.level().getBlockEntity(buf.readBlockPos()), new SimpleContainerData(3));
    }

    public BloomeryMenu(int id, Inventory playerInv, BloomeryBlockEntity furnace, ContainerData data) {
        super(ModMenus.BLOOMERY.get(), id);
        this.furnace = furnace;
        this.data = data;
        addSlot(new Slot(furnace, BloomeryBlockEntity.PRIMARY, 56, 17) {
            @Override public boolean mayPlace(ItemStack stack) { return BloomeryBlockEntity.isPrimary(stack); }
        });
        addSlot(new Slot(furnace, BloomeryBlockEntity.SECONDARY, 35, 17) {
            @Override public boolean mayPlace(ItemStack stack) { return BloomeryBlockEntity.isSecondary(stack); }
        });
        addSlot(new Slot(furnace, BloomeryBlockEntity.FUEL, 56, 53) {
            @Override public boolean mayPlace(ItemStack stack) { return BloomeryBlockEntity.burnTimeOf(stack) > 0; }
        });
        addSlot(new Slot(furnace, BloomeryBlockEntity.OUTPUT, 116, 35) {
            @Override public boolean mayPlace(ItemStack stack) { return false; }
        });
        CompostBinMenu.addPlayerSlots(this, playerInv, 8, 84);
        addDataSlots(data);
    }

    public boolean isBurning() { return data.get(0) > 0; }
    public int getBurnScaled(int scale) {
        int dur = data.get(1) == 0 ? 200 : data.get(1);
        return data.get(0) * scale / dur;
    }
    public int getCookScaled(int scale) { return data.get(2) * scale / 200; }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index < 4) {
                if (!moveItemStackTo(stack, 4, 40, true)) return ItemStack.EMPTY;
            } else if (BloomeryBlockEntity.isPrimary(stack)) {
                if (!moveItemStackTo(stack, 0, 1, false)) return ItemStack.EMPTY;
            } else if (BloomeryBlockEntity.isSecondary(stack)) {
                if (!moveItemStackTo(stack, 1, 2, false)) return ItemStack.EMPTY;
            } else if (BloomeryBlockEntity.burnTimeOf(stack) > 0) {
                if (!moveItemStackTo(stack, 2, 3, false)) return ItemStack.EMPTY;
            } else {
                return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) slot.set(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) { return furnace.stillValid(player); }
}
