package com.jaquadro.minecraft.gardencollection.inventory;

import com.jaquadro.minecraft.gardencollection.block.GardenPotBlock;
import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import com.jaquadro.minecraft.gardencollection.registry.ModMenus;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.SimpleContainer;

public class GardenMenu extends AbstractContainerMenu {
    private final GardenBlockEntity garden;
    private final SimpleContainer view;
    private final int plantSlots;

    public GardenMenu(int id, Inventory playerInv, FriendlyByteBuf buf) {
        this(id, playerInv, (GardenBlockEntity) playerInv.player.level().getBlockEntity(buf.readBlockPos()));
    }

    public GardenMenu(int id, Inventory playerInv, GardenBlockEntity garden) {
        super(ModMenus.GARDEN.get(), id);
        this.garden = garden;
        this.plantSlots = garden.slotCount();
        this.view = new SimpleContainer(4) {
            @Override
            public void setChanged() {
                super.setChanged();
                for (int i = 0; i < plantSlots; i++) {
                    garden.setPlant(i, getItem(i));
                }
            }
        };
        for (int i = 0; i < plantSlots; i++) view.setItem(i, garden.getPlant(i).copy());
        int[] xs = {80, 62, 98, 80};
        int[] ys = {54, 36, 36, 18};
        for (int i = 0; i < plantSlots; i++) {
            int slot = i;
            addSlot(new Slot(view, i, xs[i], ys[i]) {
                @Override
                public boolean mayPlace(ItemStack stack) {
                    return GardenPotBlock.isPlant(stack);
                }
                @Override
                public void setChanged() {
                    super.setChanged();
                    garden.setPlant(slot, getItem());
                }
            });
        }
        CompostBinMenu.addPlayerSlots(this, playerInv, 8, 122);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index < plantSlots) {
                if (!moveItemStackTo(stack, plantSlots, slots.size(), true)) return ItemStack.EMPTY;
            } else if (!moveItemStackTo(stack, 0, plantSlots, false)) {
                return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) slot.set(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) { return garden.stillValid(player); }

    @Override
    public void removed(Player player) {
        super.removed(player);
        for (int i = 0; i < plantSlots; i++) garden.setPlant(i, view.getItem(i));
    }
}
