package com.jaquadro.minecraft.gardencollection.item;

import com.jaquadro.minecraft.gardencollection.block.entity.GardenBlockEntity;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkHooks;

public class TrowelItem extends Item {
    public TrowelItem() {
        super(new Properties().stacksTo(1).durability(250));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.getBlockEntity(context.getClickedPos()) instanceof GardenBlockEntity garden) {
            if (!level.isClientSide && context.getPlayer() instanceof ServerPlayer serverPlayer) {
                NetworkHooks.openScreen(serverPlayer, new net.minecraft.world.MenuProvider() {
                    @Override
                    public net.minecraft.network.chat.Component getDisplayName() {
                        return net.minecraft.network.chat.Component.translatable("container.gardencollection.garden");
                    }

                    @Override
                    public net.minecraft.world.inventory.AbstractContainerMenu createMenu(int id, net.minecraft.world.entity.player.Inventory inv, net.minecraft.world.entity.player.Player player) {
                        return new com.jaquadro.minecraft.gardencollection.inventory.GardenMenu(id, inv, garden);
                    }
                }, context.getClickedPos());
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
