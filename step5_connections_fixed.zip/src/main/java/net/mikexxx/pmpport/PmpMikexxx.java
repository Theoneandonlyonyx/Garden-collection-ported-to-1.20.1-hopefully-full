package net.mikexxx.pmpport;

import net.mikexxx.pmpport.registry.ModBlockEntities;
import net.mikexxx.pmpport.registry.ModBlocks;
import net.mikexxx.pmpport.registry.ModCreativeTabs;
import net.mikexxx.pmpport.registry.ModItems;
import net.mikexxx.pmpport.registry.ModMenus;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(PmpMikexxx.MODID)
public class PmpMikexxx {
    public static final String MODID = "pmp_mikexxx";

    public PmpMikexxx() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModMenus.MENUS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
