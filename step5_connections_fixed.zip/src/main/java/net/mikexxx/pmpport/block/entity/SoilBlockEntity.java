package net.mikexxx.pmpport.block.entity;

import net.mikexxx.pmpport.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;

public class SoilBlockEntity extends PlantBedBlockEntity {

    public SoilBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.SOIL.get(), pos, state);
    }

    @Override
    public float bedHeight() {
        return 1.0F;
    }
}
