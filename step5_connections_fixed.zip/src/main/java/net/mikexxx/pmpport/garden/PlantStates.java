package net.mikexxx.pmpport.garden;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;

/** Turns a stored item into the block state that is drawn and grown. */
public final class PlantStates {
    private PlantStates() {}

    /** Growth-stage property names, in priority order. */
    private static final String[] GROWTH_NAMES = {"age", "stage", "growth", "growth_stage"};

    /** The growth-stage property of a block state, or null if it has none. */
    public static IntegerProperty growthProperty(BlockState state) {
        for (String name : GROWTH_NAMES) {
            for (Property<?> property : state.getProperties()) {
                if (property instanceof IntegerProperty ip && property.getName().equals(name)) {
                    return ip;
                }
            }
        }
        return null;
    }

    public static int maxOf(IntegerProperty property) {
        return property.getPossibleValues().stream().max(Integer::compare).orElse(0);
    }

    public static int minOf(IntegerProperty property) {
        return property.getPossibleValues().stream().min(Integer::compare).orElse(0);
    }

    /** Block state drawn for a stored item at a given growth age. Candles are drawn lit. */
    public static BlockState stateFor(ItemStack stack, int age) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return Blocks.AIR.defaultBlockState();
        }
        BlockState state = blockItem.getBlock().defaultBlockState();
        IntegerProperty growth = growthProperty(state);
        if (growth != null) {
            int clamped = Math.max(minOf(growth), Math.min(age, maxOf(growth)));
            state = state.setValue(growth, clamped);
        }
        if (stack.is(GardenLayout.CANDLES)) {
            for (Property<?> property : state.getProperties()) {
                if (property instanceof BooleanProperty bp && property.getName().equals("lit")) {
                    state = state.setValue(bp, true);
                }
            }
        }
        return state;
    }
}
