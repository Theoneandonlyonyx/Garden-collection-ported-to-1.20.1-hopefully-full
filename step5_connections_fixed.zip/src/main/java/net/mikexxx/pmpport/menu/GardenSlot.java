package net.mikexxx.pmpport.menu;

import net.mikexxx.pmpport.garden.GardenLayout;
import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** A plant or groundcover slot. Inactive slots are hidden and refuse items. */
public class GardenSlot extends Slot {

    private final boolean active;

    public GardenSlot(Container container, int index, int x, int y, boolean active) {
        super(container, index, x, y);
        this.active = active;
    }

    @Override
    public boolean isActive() {
        return active;
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return active && GardenLayout.isBlockItem(stack);
    }

    @Override
    public int getMaxStackSize() {
        return 1;
    }
}
