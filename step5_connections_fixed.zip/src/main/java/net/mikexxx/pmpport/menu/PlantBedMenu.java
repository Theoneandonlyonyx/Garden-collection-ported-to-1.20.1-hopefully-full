package net.mikexxx.pmpport.menu;

import net.mikexxx.pmpport.block.entity.PlantBedBlockEntity;
import net.mikexxx.pmpport.garden.GardenLayout;
import net.mikexxx.pmpport.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Arrange Plants: the bed's plant slots, a groundcover slot, and the player inventory. */
public class PlantBedMenu extends AbstractContainerMenu {

    /** Slot positions, measured from the top-left of the GUI. Grid cells are 18 pixels apart. */
    private static final int GRID_ORIGIN_X = 44;
    private static final int GRID_ORIGIN_Y = 18;
    private static final int GRID_STEP = 18;
    private static final int GROUNDCOVER_X = 143;
    private static final int GROUNDCOVER_Y = 86;

    private final PlantBedBlockEntity bed;

    /** Client side: the server sends the bed position and the mask of existing slots. */
    public PlantBedMenu(int id, Inventory inventory, FriendlyByteBuf buf) {
        this(id, inventory, PlantBedStorage.forClient(readMask(buf)), null);
    }

    /** Server side. */
    public PlantBedMenu(int id, Inventory inventory, PlantBedBlockEntity bed) {
        this(id, inventory, PlantBedStorage.forServer(bed, inventory.player), bed);
    }

    private PlantBedMenu(int id, Inventory inventory, PlantBedStorage storage, PlantBedBlockEntity bed) {
        super(ModMenus.PLANT_BED.get(), id);
        this.bed = bed;

        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            int x = GRID_ORIGIN_X + GRID_STEP * GardenLayout.GRID_X[i];
            int y = GRID_ORIGIN_Y + GRID_STEP * GardenLayout.GRID_Z[i];
            addSlot(new GardenSlot(storage, i, x, y, storage.isActive(i)));
        }
        addSlot(new GardenSlot(storage, GardenLayout.GROUNDCOVER_SLOT, GROUNDCOVER_X, GROUNDCOVER_Y, true));

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 122 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 8 + col * 18, 180));
        }
    }

    private static int readMask(FriendlyByteBuf buf) {
        buf.readBlockPos();
        return buf.readInt();
    }

    @Override
    public boolean stillValid(Player player) {
        if (bed == null) {
            return true;
        }
        Level level = bed.getLevel();
        BlockPos pos = bed.getBlockPos();
        return level != null
                && level.getBlockEntity(pos) == bed
                && player.distanceToSqr(Vec3.atCenterOf(pos)) <= 64.0;
    }

    /** Shift-click moves items between the GUI and the player inventory. */
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack original = slot.getItem();
        ItemStack copy = original.copy();

        if (index < GardenLayout.SLOT_COUNT) {
            if (!this.moveItemStackTo(original, GardenLayout.SLOT_COUNT, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else {
            boolean moved = this.moveItemStackTo(original, 0, GardenLayout.PLANT_SLOTS, false)
                    || this.moveItemStackTo(original, GardenLayout.GROUNDCOVER_SLOT, GardenLayout.SLOT_COUNT, false);
            if (!moved) {
                return ItemStack.EMPTY;
            }
        }

        if (original.isEmpty()) {
            slot.set(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return copy;
    }
}
