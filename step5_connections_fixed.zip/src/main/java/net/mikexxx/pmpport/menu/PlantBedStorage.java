package net.mikexxx.pmpport.menu;

import net.mikexxx.pmpport.block.entity.PlantBedBlockEntity;
import net.mikexxx.pmpport.garden.GardenLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * The slots of the Arrange Plants GUI.
 *
 * On the server each slot reads and writes the bed that owns it, so shared border slots live in one
 * place. On the client the menu keeps its own copy, which the server keeps up to date.
 */
public class PlantBedStorage implements Container {

    private final int mask;
    private final PlantBedBlockEntity[] owners;
    private final int[] ownerSlots;
    private final ItemStack[] local;
    private final Player inserter;

    private PlantBedStorage(int mask, PlantBedBlockEntity[] owners, int[] ownerSlots, Player inserter) {
        this.mask = mask;
        this.owners = owners;
        this.ownerSlots = ownerSlots;
        this.inserter = inserter;
        this.local = new ItemStack[GardenLayout.SLOT_COUNT];
        for (int i = 0; i < local.length; i++) {
            local[i] = ItemStack.EMPTY;
        }
    }

    public static PlantBedStorage forServer(PlantBedBlockEntity bed, Player inserter) {
        Level level = bed.getLevel();
        BlockPos pos = bed.getBlockPos();
        int mask = GardenLayout.activeMask(level, pos);
        PlantBedBlockEntity[] owners = new PlantBedBlockEntity[GardenLayout.SLOT_COUNT];
        int[] ownerSlots = new int[GardenLayout.SLOT_COUNT];
        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            if (((mask >> i) & 1) == 0) {
                continue;
            }
            GardenLayout.Owner o = GardenLayout.resolve(level, pos, i);
            if (o.active() && level.getBlockEntity(o.pos()) instanceof PlantBedBlockEntity ownerBed) {
                owners[i] = ownerBed;
                ownerSlots[i] = o.slot();
            }
        }
        owners[GardenLayout.GROUNDCOVER_SLOT] = bed;
        ownerSlots[GardenLayout.GROUNDCOVER_SLOT] = GardenLayout.GROUNDCOVER_SLOT;
        return new PlantBedStorage(mask, owners, ownerSlots, inserter);
    }

    public static PlantBedStorage forClient(int mask) {
        return new PlantBedStorage(mask, null, new int[GardenLayout.SLOT_COUNT], null);
    }

    public boolean isActive(int index) {
        if (index == GardenLayout.GROUNDCOVER_SLOT) {
            return true;
        }
        return ((mask >> index) & 1) != 0;
    }

    @Override
    public int getContainerSize() {
        return GardenLayout.SLOT_COUNT;
    }

    @Override
    public boolean isEmpty() {
        for (int i = 0; i < getContainerSize(); i++) {
            if (!getItem(i).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int index) {
        if (owners == null) {
            return local[index];
        }
        PlantBedBlockEntity owner = owners[index];
        return owner == null ? ItemStack.EMPTY : owner.getSlot(ownerSlots[index]);
    }

    @Override
    public ItemStack removeItem(int index, int count) {
        ItemStack current = getItem(index);
        if (current.isEmpty()) {
            return ItemStack.EMPTY;
        }
        ItemStack taken = current.copy();
        setItem(index, ItemStack.EMPTY);
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int index) {
        ItemStack current = getItem(index);
        setItem(index, ItemStack.EMPTY);
        return current;
    }

    @Override
    public void setItem(int index, ItemStack stack) {
        if (owners == null) {
            local[index] = stack;
            return;
        }
        PlantBedBlockEntity owner = owners[index];
        if (owner == null) {
            return;
        }
        int slot = ownerSlots[index];
        ItemStack previous = owner.getSlot(slot);
        boolean same = !stack.isEmpty() && ItemStack.isSameItem(stack, previous);
        int age = same ? owner.getAge(slot) : 0;
        // A new item faces the player who put it in. Existing items keep their facing.
        int rotation = same ? owner.getRotation(slot) : facingOf(inserter);
        owner.setSlot(slot, stack, age, rotation);
    }

    private static int facingOf(Player player) {
        return player == null ? 0 : player.getDirection().get2DDataValue();
    }

    @Override
    public void setChanged() {
        // Each owning bed saves itself when its slots change.
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }

    @Override
    public void clearContent() {
        for (int i = 0; i < getContainerSize(); i++) {
            setItem(i, ItemStack.EMPTY);
        }
    }
}
