package net.mikexxx.pmpport.registry;

import net.mikexxx.pmpport.PmpMikexxx;
import net.mikexxx.pmpport.block.entity.LargePotBlockEntity;
import net.mikexxx.pmpport.block.entity.SoilBlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, PmpMikexxx.MODID);

    public static final RegistryObject<BlockEntityType<SoilBlockEntity>> SOIL =
            BLOCK_ENTITIES.register("soil_block", () -> BlockEntityType.Builder.of(
                    SoilBlockEntity::new, ModBlocks.SOIL_BLOCK.get()).build(null));

    public static final RegistryObject<BlockEntityType<LargePotBlockEntity>> LARGE_POT =
            BLOCK_ENTITIES.register("large_pot", () -> BlockEntityType.Builder.of(
                    LargePotBlockEntity::new,
                    ModBlocks.LARGE_POTS.values().stream().map(RegistryObject::get).toArray(Block[]::new)
            ).build(null));
}
