package net.mikexxx.pmpport.registry;

import net.mikexxx.pmpport.PmpMikexxx;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.DyeColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PmpMikexxx.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN_TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + PmpMikexxx.MODID))
                    .icon(() -> ModItems.SOIL_BLOCK_ITEM.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.TROWEL.get());
                        output.accept(ModItems.SOIL_BLOCK_ITEM.get());
                        for (DyeColor color : DyeColor.values()) {
                            output.accept(ModItems.LARGE_POT_ITEMS.get(color).get());
                        }
                    })
                    .build());
}
