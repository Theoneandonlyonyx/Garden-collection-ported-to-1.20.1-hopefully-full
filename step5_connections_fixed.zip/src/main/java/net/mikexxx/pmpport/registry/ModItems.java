package net.mikexxx.pmpport.registry;

import net.mikexxx.pmpport.PmpMikexxx;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, PmpMikexxx.MODID);

    /** Opens the Arrange Plants GUI when used on a soil block or a pot. */
    public static final RegistryObject<Item> TROWEL = ITEMS.register("garden_trowel",
            () -> new Item(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> SOIL_BLOCK_ITEM = ITEMS.register("soil_block",
            () -> new BlockItem(ModBlocks.SOIL_BLOCK.get(), new Item.Properties()));

    public static final Map<DyeColor, RegistryObject<Item>> LARGE_POT_ITEMS = new EnumMap<>(DyeColor.class);

    static {
        for (DyeColor color : DyeColor.values()) {
            LARGE_POT_ITEMS.put(color, ITEMS.register(color.getName() + "_large_pot",
                    () -> new BlockItem(ModBlocks.LARGE_POTS.get(color).get(), new Item.Properties())));
        }
    }
}
