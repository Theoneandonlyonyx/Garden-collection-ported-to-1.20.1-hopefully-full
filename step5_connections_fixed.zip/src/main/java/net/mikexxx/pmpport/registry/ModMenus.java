package net.mikexxx.pmpport.registry;

import net.mikexxx.pmpport.PmpMikexxx;
import net.mikexxx.pmpport.menu.PlantBedMenu;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.network.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, PmpMikexxx.MODID);

    public static final RegistryObject<MenuType<PlantBedMenu>> PLANT_BED =
            MENUS.register("plant_bed", () -> IForgeMenuType.<PlantBedMenu>create(
                    (id, inv, buf) -> new PlantBedMenu(id, inv, buf)));
}
