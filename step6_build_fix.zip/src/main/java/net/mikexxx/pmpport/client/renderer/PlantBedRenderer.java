package net.mikexxx.pmpport.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.mikexxx.pmpport.block.entity.PlantBedBlockEntity;
import net.mikexxx.pmpport.garden.GardenLayout;
import net.mikexxx.pmpport.garden.PlantStates;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Draws the items of a bed at their real size, at the GUI positions. Scaled fruit is drawn at
 * {@link GardenLayout#SCALED_FRUIT_SCALE} and turned to the facing it was put in with. Everything is
 * lit from the air or block it occupies, so nothing is darker than its surroundings.
 */
public class PlantBedRenderer<T extends PlantBedBlockEntity> implements BlockEntityRenderer<T> {

    public PlantBedRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(T bed, float partialTick, PoseStack poseStack, MultiBufferSource buffers,
                       int packedLight, int packedOverlay) {
        Level level = bed.getLevel();
        if (level == null) {
            return;
        }
        BlockPos pos = bed.getBlockPos();
        float baseY = bed.bedHeight();
        int light = LevelRenderer.getLightColor(level, baseY >= 1.0F ? pos.above() : pos);
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();

        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            ItemStack stack = bed.getSlot(i);
            if (stack.isEmpty()) {
                continue;
            }
            BlockState state = PlantStates.stateFor(stack, bed.getAge(i));
            float x = GardenLayout.localX(i);
            float z = GardenLayout.localZ(i);
            poseStack.pushPose();
            if (GardenLayout.isScaled(stack)) {
                poseStack.translate(x, baseY, z);
                poseStack.mulPose(Axis.YP.rotationDegrees(bed.getRotation(i) * 90.0F));
                float s = GardenLayout.SCALED_FRUIT_SCALE;
                poseStack.scale(s, s, s);
                poseStack.translate(-0.5, 0.0, -0.5);
            } else {
                poseStack.translate(x - 0.5, baseY, z - 0.5);
            }
            dispatcher.renderSingleBlock(state, poseStack, buffers, light, packedOverlay);
            poseStack.popPose();
        }

        ItemStack groundcover = bed.getSlot(GardenLayout.GROUNDCOVER_SLOT);
        if (!groundcover.isEmpty()) {
            poseStack.pushPose();
            poseStack.translate(0.0, baseY, 0.0);
            BlockState state = PlantStates.stateFor(groundcover, bed.getAge(GardenLayout.GROUNDCOVER_SLOT));
            dispatcher.renderSingleBlock(state, poseStack, buffers, light, packedOverlay);
            poseStack.popPose();
        }
    }

}
